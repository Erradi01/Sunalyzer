import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useFirebaseAuth } from '@/contexts/FirebaseAuthContext';
import { commissionService, Commission, Project } from '@/services/commissionService';
import { DollarSign, TrendingUp, Clock, CheckCircle, Shield, AlertTriangle, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const CommissionDashboard: React.FC = () => {
  const { user } = useFirebaseAuth();
  const { toast } = useToast();
  const [commissions, setCommissions] = useState<Commission[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [errors, setErrors] = useState<string[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const validateUserAccess = useCallback(() => {
    if (!user) {
      setErrors(['User authentication required']);
      return false;
    }
    if (!['installer', 'client'].includes(user.userType)) {
      setErrors(['Invalid user type']);
      return false;
    }
    return true;
  }, [user]);

  const fetchData = useCallback(async (showRefreshToast = false) => {
    if (!validateUserAccess()) return;

    try {
      setRefreshing(true);
      setErrors([]);

      if (user?.userType === 'installer') {
        const [commissionsData, availableProjects] = await Promise.all([
          commissionService.getInstallerCommissions(user.id),
          commissionService.getAvailableProjects()
        ]);
        
        // Validate data integrity
        if (!Array.isArray(commissionsData) || !Array.isArray(availableProjects)) {
          throw new Error('Invalid data format received');
        }

        setCommissions(commissionsData);
        setProjects(availableProjects);
      } else {
        const clientProjects = await commissionService.getClientProjects(user.id);
        
        if (!Array.isArray(clientProjects)) {
          throw new Error('Invalid project data format');
        }
        
        setProjects(clientProjects);
      }

      setLastUpdated(new Date());
      
      if (showRefreshToast) {
        toast({
          title: "Data refreshed",
          description: "Dashboard updated with latest information",
        });
      }
    } catch (error) {
      console.error('Error fetching commission data:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to fetch data';
      setErrors([errorMessage]);
      
      toast({
        title: "Error loading data",
        description: errorMessage,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user, validateUserAccess, toast]);

  // Real-time updates every 30 seconds
  useEffect(() => {
    fetchData();
    
    const interval = setInterval(() => {
      fetchData();
    }, 30000);

    return () => clearInterval(interval);
  }, [fetchData]);

  const handleManualRefresh = () => {
    fetchData(true);
  };

  const sanitizeAmount = (amount: number): string => {
    // Ensure amount is a valid number and format safely
    const validAmount = isNaN(amount) || amount < 0 ? 0 : amount;
    return validAmount.toLocaleString();
  };

  const totalEarnings = commissions
    .filter(c => c.status === 'paid')
    .reduce((sum, c) => sum + (c.commissionAmount || 0), 0);

  const pendingEarnings = commissions
    .filter(c => c.status === 'pending')
    .reduce((sum, c) => sum + (c.commissionAmount || 0), 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading secure dashboard...</p>
        </div>
      </div>
    );
  }

  if (errors.length > 0) {
    return (
      <div className="space-y-4">
        {errors.map((error, index) => (
          <Alert key={index} variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ))}
        <Button onClick={handleManualRefresh} variant="outline">
          <RefreshCw className="h-4 w-4 mr-2" />
          Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Security and Status Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-green-500" />
          <span className="text-sm text-muted-foreground">
            Secure Dashboard • Last updated: {lastUpdated.toLocaleTimeString()}
          </span>
        </div>
        <Button 
          onClick={handleManualRefresh} 
          variant="outline" 
          size="sm"
          disabled={refreshing}
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {user?.userType === 'installer' ? (
        <>
          {/* Enhanced Stats Cards for Installers */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="border-green-200 bg-green-50/50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Earnings</CardTitle>
                <DollarSign className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-700">
                  ${sanitizeAmount(totalEarnings)}
                </div>
                <p className="text-xs text-green-600 mt-1">Verified & Secured</p>
              </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending Earnings</CardTitle>
                <Clock className="h-4 w-4 text-yellow-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-700">
                  ${sanitizeAmount(pendingEarnings)}
                </div>
                <p className="text-xs text-yellow-600 mt-1">Under Review</p>
              </CardContent>
            </Card>

            <Card className="border-blue-200 bg-blue-50/50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Completed Projects</CardTitle>
                <CheckCircle className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-700">
                  {commissions.filter(c => c.status !== 'pending').length}
                </div>
                <p className="text-xs text-blue-600 mt-1">Successfully Delivered</p>
              </CardContent>
            </Card>

            <Card className="border-purple-200 bg-purple-50/50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Commission Rate</CardTitle>
                <TrendingUp className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-700">
                  {user?.commissionRate || 10}%
                </div>
                <p className="text-xs text-purple-600 mt-1">Protected Rate</p>
              </CardContent>
            </Card>
          </div>

          {/* Available Projects with Security Indicators */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                Available Projects
                <Badge variant="outline" className="text-xs">
                  {projects.length} Available
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {projects.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <p>No projects available at the moment</p>
                    <p className="text-sm">Check back later for new opportunities</p>
                  </div>
                ) : (
                  projects.map((project) => (
                    <div key={project.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/20 transition-colors">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium">{project.title}</h4>
                          <div className="flex items-center" title="Verified Project">
                            <Shield className="h-3 w-3 text-green-500" />
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground">{project.description}</p>
                        <p className="text-sm text-muted-foreground">
                          {project.location} • {project.systemSize}kW
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">${sanitizeAmount(project.estimatedCost)}</p>
                        <p className="text-sm text-muted-foreground">
                          Est. Commission: ${sanitizeAmount(project.estimatedCost * ((user?.commissionRate || 10) / 100))}
                        </p>
                        <Button size="sm" className="mt-2">Apply Securely</Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Commission History with Enhanced Security */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                Commission History
                <Badge variant="outline" className="text-xs">
                  {commissions.length} Records
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {commissions.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <p>No commission history available</p>
                  </div>
                ) : (
                  commissions.map((commission) => (
                    <div key={commission.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium">Project #{commission.projectId}</h4>
                          <div className="flex items-center" title="Secure Transaction">
                            <Shield className="h-3 w-3 text-green-500" />
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {commission.commissionRate}% of ${sanitizeAmount(commission.amount)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">${sanitizeAmount(commission.commissionAmount)}</p>
                        <Badge variant={
                          commission.status === 'paid' ? 'default' :
                          commission.status === 'completed' ? 'secondary' : 'outline'
                        }>
                          {commission.status}
                        </Badge>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </>
      ) : (
        // Enhanced Client View
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                Your Protected Projects
                <Shield className="h-4 w-4 text-green-500" />
                <Badge variant="outline" className="text-xs">
                  {projects.length} Projects
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {projects.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <p>No projects found</p>
                    <p className="text-sm">Start your solar journey today</p>
                  </div>
                ) : (
                  projects.map((project) => (
                    <div key={project.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/20 transition-colors">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium">{project.title}</h4>
                          <div className="flex items-center" title="Secure Project">
                            <Shield className="h-3 w-3 text-green-500" />
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground">{project.description}</p>
                        <p className="text-sm text-muted-foreground">
                          {project.location} • {project.systemSize}kW
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">${sanitizeAmount(project.estimatedCost)}</p>
                        <Badge variant={
                          project.status === 'completed' ? 'default' :
                          project.status === 'in_progress' ? 'secondary' :
                          project.status === 'assigned' ? 'outline' : 'destructive'
                        }>
                          {project.status}
                        </Badge>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default CommissionDashboard;

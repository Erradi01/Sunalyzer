import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { calculateSolarNeeds, SolarCalculationResult, getLocationDetails } from '@/utils/solarCalculator';
import { USA_REGIONS, EUROPEAN_REGIONS, WORLDWIDE_REGIONS, PANEL_EFFICIENCIES, SYSTEM_DEFAULTS, type Location } from '@/utils/constants';
import CalculatorForm from '@/components/CalculatorForm';
import ResultsDashboard from '@/components/ResultsDashboard';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from "sonner";
import CalculatorHeader from '@/components/calculator/CalculatorHeader';
import LocationSelector from '@/components/calculator/LocationSelector';
import CalculatorPlaceholder from '@/components/calculator/CalculatorPlaceholder';
import CollapsedCalculator from '@/components/calculator/CollapsedCalculator';
import { useFirebaseAuth } from '@/contexts/FirebaseAuthContext';
import { Button } from '@/components/ui/button';
import { Save, Download } from 'lucide-react';
import PremiumFeatures from '@/components/premium/PremiumFeatures';

interface SolarCalculatorProps {
  premiumMode?: boolean;
}

const SolarCalculator: React.FC<SolarCalculatorProps> = ({ premiumMode = false }) => {
  const { user, isAuthenticated } = useFirebaseAuth();
  
  const [dailyConsumption, setDailyConsumption] = useState(SYSTEM_DEFAULTS.defaultDailyUsage);
  const [panelEfficiency, setPanelEfficiency] = useState(PANEL_EFFICIENCIES.standard);
  const [includesBattery, setIncludesBattery] = useState(false);
  const [batteryDays, setBatteryDays] = useState(1);
  const [professionalMode, setProfessionalMode] = useState(false);
  const [roofAngle, setRoofAngle] = useState(30);
  const [shadingFactor, setShadingFactor] = useState(0.95);
  const [systemTemperature, setSystemTemperature] = useState(30);
  const [calculationResults, setCalculationResults] = useState<SolarCalculationResult | null>(null);
  const [isExpanded, setIsExpanded] = useState(premiumMode ? true : false);
  const [selectedLocation, setSelectedLocation] = useState<Location>(USA_REGIONS[0]);
  const [isCalculating, setIsCalculating] = useState(false);
  const [regionType, setRegionType] = useState<'usa' | 'europe' | 'worldwide'>(premiumMode ? 'worldwide' : 'usa');
  
  // Premium-only features
  const [multiZone, setMultiZone] = useState(false);
  const [customUtilityRates, setCustomUtilityRates] = useState(false);
  
  const handleLocationChange = (value: string) => {
    const allRegions = regionType === 'usa' ? USA_REGIONS : 
                     regionType === 'europe' ? EUROPEAN_REGIONS : 
                     WORLDWIDE_REGIONS;
    const location = allRegions.find(region => region.name === value);
    if (location) {
      setSelectedLocation(location);
    }
  };
  
  const handleCalculate = () => {
    setIsCalculating(true);
    
    // Simulate a brief calculation delay for better UX
    setTimeout(() => {
      const results = calculateSolarNeeds({
        dailyConsumption,
        location: selectedLocation.name,
        latitude: selectedLocation.latitude,
        sunHours: selectedLocation.sunHours,
        panelEfficiency,
        includesBattery,
        batteryDays,
        professionalMode,
        roofAngle,
        shadingFactor,
        systemTemperature
      });
      
      setCalculationResults(results);
      if (!isExpanded) {
        setIsExpanded(true);
      }
      
      toast("Calculation complete!", {
        description: `Your ${dailyConsumption} kWh system would need approximately ${Math.round(results.numberOfPanels)} panels`,
        action: {
          label: "View Details",
          onClick: () => {
            console.log("View calculation details clicked");
          },
        },
      });
      
      setIsCalculating(false);
    }, 800);
  };

  const handleRegionTypeChange = (value: 'usa' | 'europe' | 'worldwide') => {
    if (!premiumMode && value === 'worldwide') {
      toast.error("Worldwide locations require a premium plan", {
        description: "Upgrade to access worldwide location data",
        action: {
          label: "View Plans",
          onClick: () => window.location.href = '/pricing',
        },
      });
      return;
    }
    
    setRegionType(value);
    // Set the default location based on the region type
    if (value === 'usa') {
      setSelectedLocation(USA_REGIONS[0]);
    } else if (value === 'europe') {
      setSelectedLocation(EUROPEAN_REGIONS[0]);
    } else {
      setSelectedLocation(WORLDWIDE_REGIONS[0]);
    }
  };

  const handleSaveCalculation = () => {
    if (!isAuthenticated) {
      toast("Please log in to save calculations", {
        description: "Create an account or log in to save your calculation results",
        action: {
          label: "Login",
          onClick: () => window.location.href = '/login',
        },
      });
      return;
    }
    
    if (!premiumMode) {
      toast("Premium feature", {
        description: "Saving calculations requires a premium plan",
        action: {
          label: "Upgrade",
          onClick: () => window.location.href = '/pricing',
        },
      });
      return;
    }
    
    toast.success("Calculation saved successfully!");
  };
  
  const handleGeneratePDF = () => {
    if (!isAuthenticated) {
      toast("Please log in to generate PDF reports", {
        description: "Create an account or log in to access PDF functionality",
        action: {
          label: "Login",
          onClick: () => window.location.href = '/login',
        },
      });
      return;
    }
    
    if (!calculationResults) {
      toast.error("No calculation data available", {
        description: "Please run a calculation first to generate a PDF report"
      });
      return;
    }
    
    // Generate PDF with calculation results
    toast.success("Generating PDF report...", {
      description: "Your solar calculation report will download shortly"
    });
    
    // Simulate PDF generation and download
    setTimeout(() => {
      const pdfContent = generatePDFContent(calculationResults, selectedLocation);
      downloadPDF(pdfContent, `solar-calculation-${selectedLocation.name}-${new Date().toISOString().split('T')[0]}.pdf`);
    }, 1500);
  };

  // Simple PDF generation function
  const generatePDFContent = (results: SolarCalculationResult, location: Location) => {
    return `
Solar Energy Calculation Report
Generated on: ${new Date().toLocaleDateString()}
Location: ${location.name}${location.state ? `, ${location.state}` : ''}${location.country ? `, ${location.country}` : ''}

SYSTEM SPECIFICATIONS:
- Daily Energy Consumption: ${dailyConsumption} kWh
- Recommended System Size: ${results.systemSizeKW.toFixed(2)} kW
- Number of Solar Panels: ${results.numberOfPanels}
- Daily Energy Production: ${results.dailyProduction.toFixed(2)} kWh
- Annual Energy Production: ${results.annualProduction.toFixed(0)} kWh

FINANCIAL ANALYSIS:
- Installation Cost: $${results.installationCost.toLocaleString()}
- Federal Tax Credit: $${results.federalIncentive.toLocaleString()}
- State Incentive: $${results.stateIncentive.toLocaleString()}
- Net Cost: $${results.netCost.toLocaleString()}
- Annual Savings: $${results.annualSavings.toLocaleString()}
- Payback Period: ${results.paybackPeriod.toFixed(1)} years

${includesBattery ? `
BATTERY STORAGE:
- Battery Capacity: ${results.batterySize.toFixed(0)} Wh
- Battery Cost: $${results.batteryCost.toLocaleString()}
- Backup Duration: ${batteryDays} day(s)
` : ''}

This report was generated by Sunalyzer Solar Calculator.
`;
  };

  const downloadPDF = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success("PDF downloaded successfully!", {
      description: `Report saved as ${filename}`
    });
  };

  return (
    <motion.div 
      className="max-w-4xl mx-auto"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className={`shadow-lg overflow-hidden border-t-4 ${premiumMode ? 'border-t-primary' : 'border-t-solar-yellow'}`}>
        <CardContent className="p-0">
          <div className="p-6 bg-gradient-to-r from-yellow-50 via-blue-50 to-yellow-50">
            <CalculatorHeader 
              isExpanded={isExpanded} 
              onExpandToggle={() => setIsExpanded(!isExpanded)}
              premiumMode={premiumMode}
            />
            
            <AnimatePresence>
              {isExpanded ? (
                <motion.div 
                  className="grid grid-cols-1 md:grid-cols-2 gap-6"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <motion.div 
                    className="bg-white/90 backdrop-blur-sm rounded-xl shadow-sm p-5"
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.1 }}
                  >
                    <LocationSelector
                      regionType={regionType}
                      selectedLocation={selectedLocation}
                      onRegionTypeChange={handleRegionTypeChange}
                      onLocationChange={handleLocationChange}
                      premiumMode={premiumMode}
                    />

                    <CalculatorForm 
                      dailyConsumption={dailyConsumption}
                      setDailyConsumption={setDailyConsumption}
                      panelEfficiency={panelEfficiency}
                      setPanelEfficiency={setPanelEfficiency}
                      includesBattery={includesBattery}
                      setIncludesBattery={setIncludesBattery}
                      batteryDays={batteryDays}
                      setBatteryDays={setBatteryDays}
                      professionalMode={professionalMode}
                      setProfessionalMode={setProfessionalMode}
                      roofAngle={roofAngle}
                      setRoofAngle={setRoofAngle}
                      shadingFactor={shadingFactor}
                      setShadingFactor={setShadingFactor}
                      systemTemperature={systemTemperature}
                      setSystemTemperature={setSystemTemperature}
                      onCalculate={handleCalculate}
                      isCalculating={isCalculating}
                      premiumMode={premiumMode}
                    />

                    {premiumMode && user?.subscriptionTier === 'professional' && (
                      <PremiumFeatures 
                        multiZone={multiZone}
                        setMultiZone={setMultiZone}
                        customUtilityRates={customUtilityRates}
                        setCustomUtilityRates={setCustomUtilityRates}
                      />
                    )}
                  </motion.div>

                  <motion.div 
                    className="bg-white/90 backdrop-blur-sm rounded-xl shadow-sm p-5"
                    initial={{ x: 20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    {calculationResults ? (
                      <>
                        <ResultsDashboard results={calculationResults} />
                        
                        {/* Action buttons for results */}
                        <div className="flex gap-3 mt-6">
                          <Button 
                            className="flex-1 flex items-center gap-2"
                            onClick={handleSaveCalculation}
                          >
                            <Save className="h-4 w-4" />
                            Save Calculation
                          </Button>
                          
                          <Button 
                            variant="outline" 
                            className="flex-1 flex items-center gap-2"
                            onClick={handleGeneratePDF}
                          >
                            <Download className="h-4 w-4" />
                            Generate PDF
                          </Button>
                        </div>
                      </>
                    ) : (
                      <CalculatorPlaceholder 
                        onCalculate={handleCalculate}
                        isCalculating={isCalculating}
                      />
                    )}
                  </motion.div>
                </motion.div>
              ) : (
                <CollapsedCalculator onExpand={() => setIsExpanded(true)} />
              )}
            </AnimatePresence>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default SolarCalculator;


import React from 'react';
import { Outlet, Link } from 'react-router-dom';
import { useFirebaseAuth } from '@/contexts/FirebaseAuthContext';
import { Button } from '@/components/ui/button';
import { User, LogIn, Sun, Calculator, DollarSign, Users, FileText, InfoIcon, Star, Menu, X, Newspaper, Settings, Shield, Phone, Mail, MapPin, Facebook, Twitter, Linkedin, Youtube } from 'lucide-react';
import { useState } from 'react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

const Layout: React.FC = () => {
  const { user, logout, isAuthenticated } = useFirebaseAuth();
  const isPremiumUser = user?.subscriptionTier && ['basic', 'professional', 'enterprise'].includes(user.subscriptionTier);
  const isAdmin = user?.email === 'webdeveapp@gmail.com';
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const NavigationItems = () => (
    <>
      <Link to="/" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-1">
        <Calculator className="h-3 w-3" />
        Free Calculator
      </Link>
      <Link to="/solar-design" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-1">
        <Star className="h-3 w-3 text-solar-yellow" />
        Pro Design Tool
      </Link>
      {isPremiumUser && (
        <Link to="/premium-calculator" className="text-sm font-medium hover:text-primary flex items-center gap-1 transition-colors">
          <Star className="h-3 w-3 text-solar-yellow fill-solar-yellow" />
          Premium Calculator
        </Link>
      )}
      <Link to="/pricing" className="text-sm font-medium hover:text-primary transition-colors">
        Pricing
      </Link>
      <Link to="/installer-directory" className="text-sm font-medium hover:text-primary transition-colors">
        Find Installers
      </Link>
      <Link to="/energy-news" className="text-sm font-medium hover:text-primary flex items-center gap-1 transition-colors">
        <Newspaper className="h-3 w-3" />
        Energy News
      </Link>
      <Link to="/about" className="text-sm font-medium hover:text-primary transition-colors">
        About
      </Link>
      {isAuthenticated ? (
        <>
          <Link to="/dashboard" className="text-sm font-medium hover:text-primary transition-colors">
            Dashboard
          </Link>
          {isAdmin && (
            <Link to="/admin" className="text-sm font-medium hover:text-primary flex items-center gap-1 transition-colors text-red-600">
              <Settings className="h-3 w-3" />
              Admin
            </Link>
          )}
        </>
      ) : null}
    </>
  );

  return (
    <div className="flex flex-col min-h-screen">
      {/* Top Banner */}
      <div className="bg-primary text-primary-foreground py-2 text-center text-sm">
        <div className="container px-4 mx-auto">
          🌟 Free Solar Calculator for USA | Professional Design Tools Available | Save Up to 30% with Federal Tax Credits
        </div>
      </div>

      <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container px-4 mx-auto">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-6">
              <Link to="/" className="font-mono text-xl font-bold flex items-center gap-2">
                <Sun className="h-6 w-6 text-primary" />
                <span>Sunalyzer</span>
              </Link>
              
              {/* Desktop Navigation */}
              <nav className="hidden lg:flex items-center gap-6">
                <NavigationItems />
              </nav>
            </div>

            <div className="flex items-center gap-2">
              {isAuthenticated ? (
                <>
                  <Link to="/profile">
                    <Button variant="outline" size="sm" className="hidden sm:flex items-center gap-2">
                      <User className="h-4 w-4" />
                      {user?.name || 'Profile'}
                      {isPremiumUser && (
                        <span className="text-xs bg-primary/10 text-primary px-1.5 rounded-full">
                          {user?.subscriptionTier}
                        </span>
                      )}
                      {isAdmin && (
                        <span className="text-xs bg-red-100 text-red-600 px-1.5 rounded-full">
                          Admin
                        </span>
                      )}
                    </Button>
                  </Link>
                  <Button variant="ghost" size="sm" onClick={() => logout()}>
                    Logout
                  </Button>
                </>
              ) : (
                <>
                  <Link to="/login">
                    <Button variant="outline" size="sm" className="hidden sm:flex items-center gap-2">
                      <LogIn className="h-4 w-4" />
                      Login
                    </Button>
                  </Link>
                  <Link to="/register">
                    <Button variant="default" size="sm">
                      Sign Up
                    </Button>
                  </Link>
                </>
              )}

              {/* Mobile Menu */}
              <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="sm" className="lg:hidden">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                  <div className="flex flex-col gap-4 mt-6">
                    <div className="font-mono text-lg font-bold flex items-center gap-2 mb-4">
                      <Sun className="h-5 w-5 text-primary" />
                      <span>Sunalyzer</span>
                    </div>
                    <nav className="flex flex-col gap-3">
                      <NavigationItems />
                    </nav>
                    {isAuthenticated && (
                      <div className="pt-4 border-t">
                        <Link to="/profile" className="block py-2">
                          <Button variant="outline" className="w-full justify-start">
                            <User className="h-4 w-4 mr-2" />
                            {user?.name || 'Profile'}
                          </Button>
                        </Link>
                      </div>
                    )}
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        <Outlet />
      </main>

      {/* Enhanced Footer */}
      <footer className="py-12 border-t border-border bg-background">
        <div className="container px-4 mx-auto">
          {/* Main Footer Content */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-8">
            {/* Company Info */}
            <div className="lg:col-span-2">
              <div className="font-mono text-xl font-bold flex items-center gap-2 mb-4">
                <Sun className="h-6 w-6 text-primary" />
                <span>Sunalyzer</span>
              </div>
              <p className="text-muted-foreground mb-4 max-w-md">
                The most comprehensive solar energy calculator for homeowners and professionals. Calculate savings, design systems, and find trusted installers.
              </p>
              <div className="space-y-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  <span>Serving all 50 US States</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <a href="mailto:privacy.sunalyzer@gmail.com" className="hover:text-primary">
                    privacy.sunalyzer@gmail.com
                  </a>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  <span>SSL Secured & Privacy Protected</span>
                </div>
              </div>
            </div>

            {/* Quick Tools */}
            <div>
              <h3 className="font-medium mb-4 flex items-center gap-2">
                <Calculator className="h-4 w-4" />
                Quick Tools
              </h3>
              <ul className="space-y-3">
                <li>
                  <Link to="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    Free Solar Calculator
                  </Link>
                </li>
                <li>
                  <Link to="/solar-design" className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center gap-1">
                    <Star className="h-3 w-3 text-solar-yellow" />
                    Pro Design Tool
                  </Link>
                </li>
                <li>
                  <Link to="/installer-directory" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    Find Local Installers
                  </Link>
                </li>
                <li>
                  <Link to="/energy-news" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    Energy Market News
                  </Link>
                </li>
                {isPremiumUser && (
                  <li>
                    <Link to="/premium-calculator" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                      Premium Features
                    </Link>
                  </li>
                )}
              </ul>
            </div>

            {/* Services */}
            <div>
              <h3 className="font-medium mb-4">Services</h3>
              <ul className="space-y-3">
                <li><Link to="/pricing" className="text-sm text-muted-foreground hover:text-primary transition-colors">Pricing Plans</Link></li>
                <li><Link to="/saas-plans" className="text-sm text-muted-foreground hover:text-primary transition-colors">SaaS Solutions</Link></li>
                <li><Link to="/service-plans" className="text-sm text-muted-foreground hover:text-primary transition-colors">Service Plans</Link></li>
                {isAuthenticated && (
                  <>
                    <li><Link to="/saved-calculations" className="text-sm text-muted-foreground hover:text-primary transition-colors">Saved Calculations</Link></li>
                    <li><Link to="/dashboard" className="text-sm text-muted-foreground hover:text-primary transition-colors">Account Dashboard</Link></li>
                  </>
                )}
              </ul>
            </div>

            {/* Support & Legal */}
            <div>
              <h3 className="font-medium mb-4">Support & Legal</h3>
              <ul className="space-y-3">
                <li><Link to="/about" className="text-sm text-muted-foreground hover:text-primary transition-colors">About Us</Link></li>
                <li><Link to="/blog" className="text-sm text-muted-foreground hover:text-primary transition-colors">Blog & Guides</Link></li>
                <li><Link to="/privacy" className="text-sm text-muted-foreground hover:text-primary transition-colors">Privacy Policy</Link></li>
                <li><Link to="/terms" className="text-sm text-muted-foreground hover:text-primary transition-colors">Terms of Service</Link></li>
                <li>
                  <a href="mailto:privacy.sunalyzer@gmail.com" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    Contact Support
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Social Media & Trust Indicators */}
          <div className="border-t border-border pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <div className="flex items-center gap-4">
                <span className="text-sm text-muted-foreground">Follow us:</span>
                <div className="flex gap-3">
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                    <Facebook className="h-4 w-4" />
                  </a>
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                    <Twitter className="h-4 w-4" />
                  </a>
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                    <Linkedin className="h-4 w-4" />
                  </a>
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                    <Youtube className="h-4 w-4" />
                  </a>
                </div>
              </div>
              
              <div className="flex items-center gap-6 text-xs text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Shield className="h-3 w-3" />
                  <span>SSL Secured</span>
                </div>
                <div className="flex items-center gap-1">
                  <Star className="h-3 w-3 text-solar-yellow fill-solar-yellow" />
                  <span>Trusted by 10,000+ Users</span>
                </div>
              </div>
            </div>
          </div>

          {/* Copyright */}
          <div className="text-center text-sm text-muted-foreground pt-6 border-t border-border mt-6">
            <p className="mb-2">© {new Date().getFullYear()} Sunalyzer Solar Energy Calculator. All rights reserved.</p>
            <p className="text-xs">All calculations are estimates. Actual results may vary based on local conditions, equipment, and installation factors.</p>
            <p className="text-xs mt-1">🌱 Helping America transition to clean, renewable solar energy</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;

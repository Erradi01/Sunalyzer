
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Smartphone, Wallet, Check, Shield } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import StripePayment from './StripePayment';
import PayPalPayment from './PayPalPayment';
import GooglePayButton from './GooglePayButton';
import ApplePayButton from './ApplePayButton';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPlan?: {
    name: string;
    price: string;
    period?: string;
    features: string[];
  };
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, selectedPlan }) => {
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('stripe');
  const [isProcessing, setIsProcessing] = useState(false);

  const paymentMethods = [
    {
      id: 'stripe',
      name: 'Credit/Debit Card',
      icon: CreditCard,
      description: 'Secure payment with Stripe',
      badges: ['Most Popular', 'Secure']
    },
    {
      id: 'googlepay',
      name: 'Google Pay',
      icon: Smartphone,
      description: 'Quick payment with Google Pay',
      badges: ['Fast', 'Convenient']
    },
    {
      id: 'applepay',
      name: 'Apple Pay',
      icon: Smartphone,
      description: 'Secure payment with Apple Pay',
      badges: ['Touch ID', 'Secure']
    },
    {
      id: 'paypal',
      name: 'PayPal',
      icon: Wallet,
      description: 'Pay with your PayPal account',
      badges: ['Trusted', 'Buyer Protection']
    }
  ];

  if (!selectedPlan) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Complete Your Subscription</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Plan Summary */}
          <div className="space-y-4">
            <Card className="border-primary">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  {selectedPlan.name}
                  <Badge variant="default">Selected</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-4">
                  {selectedPlan.price}
                  {selectedPlan.period && <span className="text-lg text-muted-foreground">/{selectedPlan.period}</span>}
                </div>
                <ul className="space-y-2">
                  {selectedPlan.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Security Features */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Security & Trust
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span className="text-sm">256-bit SSL encryption</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span className="text-sm">PCI DSS compliant</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span className="text-sm">30-day money-back guarantee</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Cancel anytime</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payment Methods */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Choose Payment Method</h3>
            
            <Tabs value={selectedPaymentMethod} onValueChange={setSelectedPaymentMethod}>
              <TabsList className="grid grid-cols-2 lg:grid-cols-4 h-auto">
                {paymentMethods.map((method) => {
                  const IconComponent = method.icon;
                  return (
                    <TabsTrigger 
                      key={method.id} 
                      value={method.id}
                      className="flex flex-col items-center p-3 h-auto"
                    >
                      <IconComponent className="h-5 w-5 mb-1" />
                      <span className="text-xs">{method.name}</span>
                    </TabsTrigger>
                  );
                })}
              </TabsList>

              <div className="mt-4">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={selectedPaymentMethod}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          {(() => {
                            const method = paymentMethods.find(m => m.id === selectedPaymentMethod);
                            if (method) {
                              const IconComponent = method.icon;
                              return <IconComponent className="h-5 w-5" />;
                            }
                            return null;
                          })()}
                          {paymentMethods.find(m => m.id === selectedPaymentMethod)?.name}
                          <div className="flex gap-1 ml-auto">
                            {paymentMethods.find(m => m.id === selectedPaymentMethod)?.badges.map((badge, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {badge}
                              </Badge>
                            ))}
                          </div>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <TabsContent value="stripe" className="m-0">
                          <StripePayment 
                            plan={selectedPlan}
                            isProcessing={isProcessing}
                            setIsProcessing={setIsProcessing}
                            onSuccess={onClose}
                          />
                        </TabsContent>
                        
                        <TabsContent value="googlepay" className="m-0">
                          <GooglePayButton 
                            plan={selectedPlan}
                            isProcessing={isProcessing}
                            setIsProcessing={setIsProcessing}
                            onSuccess={onClose}
                          />
                        </TabsContent>
                        
                        <TabsContent value="applepay" className="m-0">
                          <ApplePayButton 
                            plan={selectedPlan}
                            isProcessing={isProcessing}
                            setIsProcessing={setIsProcessing}
                            onSuccess={onClose}
                          />
                        </TabsContent>
                        
                        <TabsContent value="paypal" className="m-0">
                          <PayPalPayment 
                            plan={selectedPlan}
                            isProcessing={isProcessing}
                            setIsProcessing={setIsProcessing}
                            onSuccess={onClose}
                          />
                        </TabsContent>
                      </CardContent>
                    </Card>
                  </motion.div>
                </AnimatePresence>
              </div>
            </Tabs>

            <div className="text-center text-sm text-muted-foreground">
              <p>By subscribing, you agree to our Terms of Service and Privacy Policy</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PaymentModal;


import React from 'react';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface ApplePayButtonProps {
  plan: any;
  isProcessing: boolean;
  setIsProcessing: (processing: boolean) => void;
  onSuccess: () => void;
}

const ApplePayButton: React.FC<ApplePayButtonProps> = ({ 
  plan, 
  isProcessing, 
  setIsProcessing, 
  onSuccess 
}) => {
  const handleApplePay = async () => {
    setIsProcessing(true);

    try {
      // Check if Apple Pay is available
      if (typeof window !== 'undefined' && 'ApplePaySession' in window) {
        // Simulate Apple Pay processing
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        toast.success('Apple Pay payment successful!', {
          description: `You've successfully subscribed to the ${plan.name} plan.`
        });
        
        onSuccess();
      } else {
        toast.error('Apple Pay not available', {
          description: 'Apple Pay is not available on this device or browser.'
        });
      }
    } catch (error) {
      toast.error('Apple Pay failed', {
        description: 'Please try another payment method.'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="text-center p-6 border-2 border-dashed border-muted rounded-lg">
        <div className="mb-4">
          <div className="w-16 h-16 bg-gradient-to-r from-gray-800 to-gray-600 rounded-full mx-auto flex items-center justify-center text-white font-bold text-xl">
            
          </div>
        </div>
        <h3 className="font-semibold mb-2">Apple Pay</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Pay securely with Touch ID or Face ID
        </p>
        
        <Button 
          onClick={handleApplePay}
          className="w-full bg-black hover:bg-gray-800" 
          size="lg"
          disabled={isProcessing}
        >
          {isProcessing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              Pay {plan.price} with Apple Pay
            </>
          )}
        </Button>
      </div>
      
      <div className="text-center text-xs text-muted-foreground">
        <p>Secure payment with biometric authentication</p>
      </div>
    </div>
  );
};

export default ApplePayButton;

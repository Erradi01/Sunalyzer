
import React from 'react';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface PayPalPaymentProps {
  plan: any;
  isProcessing: boolean;
  setIsProcessing: (processing: boolean) => void;
  onSuccess: () => void;
}

const PayPalPayment: React.FC<PayPalPaymentProps> = ({ 
  plan, 
  isProcessing, 
  setIsProcessing, 
  onSuccess 
}) => {
  const handlePayPal = async () => {
    setIsProcessing(true);

    try {
      // Simulate PayPal processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast.success('PayPal payment successful!', {
        description: `You've successfully subscribed to the ${plan.name} plan.`
      });
      
      onSuccess();
    } catch (error) {
      toast.error('PayPal payment failed', {
        description: 'Please try again or use another payment method.'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="text-center p-6 border-2 border-dashed border-muted rounded-lg">
        <div className="mb-4">
          <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-blue-800 rounded-full mx-auto flex items-center justify-center text-white font-bold">
            PP
          </div>
        </div>
        <h3 className="font-semibold mb-2">PayPal</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Pay with your PayPal account or credit card
        </p>
        
        <Button 
          onClick={handlePayPal}
          className="w-full bg-blue-600 hover:bg-blue-700" 
          size="lg"
          disabled={isProcessing}
        >
          {isProcessing ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Redirecting to PayPal...
            </>
          ) : (
            <>
              Pay {plan.price} with PayPal
            </>
          )}
        </Button>
      </div>
      
      <div className="text-center text-xs text-muted-foreground">
        <p>Buyer protection included</p>
      </div>
    </div>
  );
};

export default PayPalPayment;

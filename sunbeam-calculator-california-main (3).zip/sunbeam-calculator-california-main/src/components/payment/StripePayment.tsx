
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, CreditCard, Lock } from 'lucide-react';
import { toast } from 'sonner';

interface StripePaymentProps {
  plan: any;
  isProcessing: boolean;
  setIsProcessing: (processing: boolean) => void;
  onSuccess: () => void;
}

const StripePayment: React.FC<StripePaymentProps> = ({ 
  plan, 
  isProcessing, 
  setIsProcessing, 
  onSuccess 
}) => {
  const [cardData, setCardData] = useState({
    number: '',
    expiry: '',
    cvv: '',
    name: '',
    email: '',
    address: '',
    city: '',
    zip: ''
  });

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\s/g, '').replace(/[^0-9]/gi, '');
    const formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
    setCardData({ ...cardData, number: formattedValue });
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length >= 2) {
      value = value.substring(0, 2) + '/' + value.substring(2, 4);
    }
    setCardData({ ...cardData, expiry: value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast.success('Payment successful!', {
        description: `You've successfully subscribed to the ${plan.name} plan.`
      });
      
      onSuccess();
    } catch (error) {
      toast.error('Payment failed', {
        description: 'Please check your card details and try again.'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-4">
        <div>
          <Label htmlFor="email">Email Address</Label>
          <Input
            id="email"
            type="email"
            value={cardData.email}
            onChange={(e) => setCardData({ ...cardData, email: e.target.value })}
            placeholder="your@email.com"
            required
          />
        </div>

        <div>
          <Label htmlFor="cardNumber">Card Number</Label>
          <div className="relative">
            <Input
              id="cardNumber"
              value={cardData.number}
              onChange={handleCardNumberChange}
              placeholder="1234 5678 9012 3456"
              maxLength={19}
              required
            />
            <CreditCard className="absolute right-3 top-3 h-4 w-4 text-muted-foreground" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="expiry">Expiry Date</Label>
            <Input
              id="expiry"
              value={cardData.expiry}
              onChange={handleExpiryChange}
              placeholder="MM/YY"
              maxLength={5}
              required
            />
          </div>
          <div>
            <Label htmlFor="cvv">CVV</Label>
            <Input
              id="cvv"
              value={cardData.cvv}
              onChange={(e) => setCardData({ ...cardData, cvv: e.target.value.replace(/\D/g, '') })}
              placeholder="123"
              maxLength={4}
              required
            />
          </div>
        </div>

        <div>
          <Label htmlFor="name">Cardholder Name</Label>
          <Input
            id="name"
            value={cardData.name}
            onChange={(e) => setCardData({ ...cardData, name: e.target.value })}
            placeholder="John Doe"
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="city">City</Label>
            <Input
              id="city"
              value={cardData.city}
              onChange={(e) => setCardData({ ...cardData, city: e.target.value })}
              placeholder="San Francisco"
              required
            />
          </div>
          <div>
            <Label htmlFor="zip">ZIP Code</Label>
            <Input
              id="zip"
              value={cardData.zip}
              onChange={(e) => setCardData({ ...cardData, zip: e.target.value })}
              placeholder="94102"
              required
            />
          </div>
        </div>
      </div>

      <Button 
        type="submit" 
        className="w-full" 
        size="lg"
        disabled={isProcessing}
      >
        {isProcessing ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Processing Payment...
          </>
        ) : (
          <>
            <Lock className="mr-2 h-4 w-4" />
            Pay {plan.price} Securely
          </>
        )}
      </Button>

      <div className="text-center text-xs text-muted-foreground">
        <p>Your payment information is encrypted and secure</p>
      </div>
    </form>
  );
};

export default StripePayment;

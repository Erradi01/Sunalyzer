
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Sun, Battery, Zap, Leaf } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface SlideData {
  id: number;
  title: string;
  description: string;
  image: string;
  icon: React.ReactNode;
  bgGradient: string;
}

const SolarImageCarousel: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [autoPlay, setAutoPlay] = useState(true);

  const slides: SlideData[] = [
    {
      id: 1,
      title: "Solar Panel Installation",
      description: "Professional installation with cutting-edge technology",
      image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
      icon: <Sun className="h-8 w-8 text-yellow-500" />,
      bgGradient: "from-yellow-400/20 to-orange-500/20"
    },
    {
      id: 2,
      title: "Battery Storage Systems",
      description: "Store energy for maximum efficiency and independence",
      image: "https://images.unsplash.com/photo-1511818966892-d7d671e672a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=2071&q=80",
      icon: <Battery className="h-8 w-8 text-green-500" />,
      bgGradient: "from-green-400/20 to-blue-500/20"
    },
    {
      id: 3,
      title: "Smart Energy Management",
      description: "Real-time monitoring and optimization of your solar system",
      image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
      icon: <Zap className="h-8 w-8 text-blue-500" />,
      bgGradient: "from-blue-400/20 to-purple-500/20"
    },
    {
      id: 4,
      title: "Environmental Impact",
      description: "Reduce your carbon footprint with clean energy solutions",
      image: "https://images.unsplash.com/photo-1466611653911-95081537e5b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
      icon: <Leaf className="h-8 w-8 text-green-600" />,
      bgGradient: "from-green-500/20 to-emerald-400/20"
    }
  ];

  useEffect(() => {
    if (!autoPlay) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [autoPlay, slides.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
    setAutoPlay(false);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
    setAutoPlay(false);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
    setAutoPlay(false);
  };

  return (
    <div className="relative h-96 md:h-[500px] rounded-2xl overflow-hidden bg-gradient-to-br from-zinc-100 to-zinc-200">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0, x: 300 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -300 }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
          className="absolute inset-0"
        >
          <div className={`absolute inset-0 bg-gradient-to-br ${slides[currentSlide].bgGradient}`} />
          <img
            src={slides[currentSlide].image}
            alt={slides[currentSlide].title}
            className="w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-black/30" />
          
          <div className="absolute bottom-0 left-0 right-0 p-6 md:p-8 text-white">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="flex items-center gap-3 mb-3"
            >
              {slides[currentSlide].icon}
              <h3 className="text-2xl md:text-3xl font-bold">{slides[currentSlide].title}</h3>
            </motion.div>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="text-lg md:text-xl text-white/90 max-w-2xl"
            >
              {slides[currentSlide].description}
            </motion.p>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation Buttons */}
      <Button
        variant="secondary"
        size="icon"
        onClick={prevSlide}
        className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/10 hover:bg-white/20 border-white/20"
      >
        <ChevronLeft className="h-5 w-5 text-white" />
      </Button>
      
      <Button
        variant="secondary"
        size="icon"
        onClick={nextSlide}
        className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/10 hover:bg-white/20 border-white/20"
      >
        <ChevronRight className="h-5 w-5 text-white" />
      </Button>

      {/* Slide Indicators */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide 
                ? 'bg-white scale-110' 
                : 'bg-white/50 hover:bg-white/70'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default SolarImageCarousel;

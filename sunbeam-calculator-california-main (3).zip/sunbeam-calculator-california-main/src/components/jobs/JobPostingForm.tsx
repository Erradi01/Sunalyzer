
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { MapPin, DollarSign, Calendar, Briefcase } from 'lucide-react';
import { toast } from 'sonner';
import { JOB_CATEGORIES, JOB_URGENCY_LEVELS, USA_REGIONS, EUROPEAN_REGIONS, type Location } from '@/utils/constants';

interface JobPostingFormProps {
  onJobPosted?: (job: any) => void;
}

const JobPostingForm: React.FC<JobPostingFormProps> = ({ onJobPosted }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    location: '',
    budget: '',
    urgency: '',
    systemSize: '',
    propertyType: 'residential'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.title || !formData.description || !formData.category || !formData.location) {
      toast.error('Please fill in all required fields');
      return;
    }

    const newJob = {
      id: Date.now().toString(),
      ...formData,
      postedAt: new Date().toISOString(),
      status: 'open',
      proposalCount: 0
    };

    toast.success('Job posted successfully!', {
      description: 'Your solar project has been posted and installers will start sending proposals.'
    });

    if (onJobPosted) {
      onJobPosted(newJob);
    }

    // Reset form
    setFormData({
      title: '',
      description: '',
      category: '',
      location: '',
      budget: '',
      urgency: '',
      systemSize: '',
      propertyType: 'residential'
    });
  };

  const allLocations: Location[] = [...USA_REGIONS, ...EUROPEAN_REGIONS];

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Briefcase className="h-5 w-5" />
          Post a Solar Project
        </CardTitle>
        <p className="text-muted-foreground">
          Describe your solar project and get quotes from qualified installers
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="title">Project Title *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="e.g., Residential Solar Installation - 8kW System"
              required
            />
          </div>

          <div>
            <Label htmlFor="category">Project Category *</Label>
            <Select
              value={formData.category}
              onValueChange={(value) => setFormData({ ...formData, category: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select project type" />
              </SelectTrigger>
              <SelectContent>
                {JOB_CATEGORIES.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="location">Location *</Label>
              <Select
                value={formData.location}
                onValueChange={(value) => setFormData({ ...formData, location: value })}
              >
                <SelectTrigger>
                  <MapPin className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Select location" />
                </SelectTrigger>
                <SelectContent>
                  {allLocations.map((location) => (
                    <SelectItem key={location.name} value={location.name}>
                      {location.name}{location.state ? `, ${location.state}` : ''}{location.country ? `, ${location.country}` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="urgency">Timeline</Label>
              <Select
                value={formData.urgency}
                onValueChange={(value) => setFormData({ ...formData, urgency: value })}
              >
                <SelectTrigger>
                  <Calendar className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Select timeline" />
                </SelectTrigger>
                <SelectContent>
                  {JOB_URGENCY_LEVELS.map((level) => (
                    <SelectItem key={level.value} value={level.value}>
                      {level.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="budget">Budget Range</Label>
              <Select
                value={formData.budget}
                onValueChange={(value) => setFormData({ ...formData, budget: value })}
              >
                <SelectTrigger>
                  <DollarSign className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Select budget range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="under-10k">Under $10,000</SelectItem>
                  <SelectItem value="10k-20k">$10,000 - $20,000</SelectItem>
                  <SelectItem value="20k-30k">$20,000 - $30,000</SelectItem>
                  <SelectItem value="30k-50k">$30,000 - $50,000</SelectItem>
                  <SelectItem value="over-50k">Over $50,000</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="systemSize">System Size (optional)</Label>
              <Input
                id="systemSize"
                value={formData.systemSize}
                onChange={(e) => setFormData({ ...formData, systemSize: e.target.value })}
                placeholder="e.g., 8kW"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="description">Project Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe your project requirements, property details, and any specific needs..."
              rows={4}
              required
            />
          </div>

          <Button type="submit" className="w-full">
            Post Project
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default JobPostingForm;

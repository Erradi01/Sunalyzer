
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useFirebaseAuth } from '@/contexts/FirebaseAuthContext';
import { Search, TrendingUp, TrendingDown, DollarSign, CheckCircle, Save, Download, LogIn } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { ToastAction } from '@/components/ui/toast';
import { useNavigate } from 'react-router-dom';

interface ServicePlan {
  id: string;
  name: string;
  basePrice: number;
  currentPrice: number;
  description: string;
  features: string[];
  trend: 'up' | 'down' | 'stable';
  availability: 'high' | 'medium' | 'low';
  estimatedInstallTime: string;
  isInstallationComplete?: boolean;
}

const RealTimePricing: React.FC = () => {
  const { user, isAuthenticated } = useFirebaseAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [services, setServices] = useState<ServicePlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [quoteRequested, setQuoteRequested] = useState<string | null>(null);

  // Updated services with your specified pricing
  const mockServices: ServicePlan[] = [
    {
      id: 'residential-average',
      name: 'Complete Solar Installation - Average Home',
      basePrice: 15543.31,
      currentPrice: 15000,
      description: 'Complete solar installation package for average residential homes',
      features: ['6-8kW System', '24-32 Panels', 'Complete Installation', '25-year warranty', 'Smart monitoring', 'Battery ready'],
      trend: 'down',
      availability: 'high',
      estimatedInstallTime: '2-3 weeks',
      isInstallationComplete: true
    },
    {
      id: 'residential-basic',
      name: 'Residential Solar Basic',
      basePrice: 15000,
      currentPrice: 14200,
      description: 'Basic solar installation for smaller homes',
      features: ['5kW System', '20 Panels', '10-year warranty', 'Basic monitoring'],
      trend: 'down',
      availability: 'high',
      estimatedInstallTime: '2-3 weeks'
    },
    {
      id: 'residential-premium',
      name: 'Residential Solar Premium',
      basePrice: 25000,
      currentPrice: 26500,
      description: 'High-efficiency solar with battery storage',
      features: ['8kW System', '28 Panels', 'Battery Storage', '25-year warranty', 'Smart monitoring'],
      trend: 'up',
      availability: 'medium',
      estimatedInstallTime: '3-4 weeks'
    },
    {
      id: 'commercial-standard',
      name: 'Commercial Solar Standard',
      basePrice: 45000,
      currentPrice: 43800,
      description: 'Commercial-grade solar solutions',
      features: ['15kW System', '50+ Panels', 'Commercial warranty', 'Fleet monitoring'],
      trend: 'down',
      availability: 'high',
      estimatedInstallTime: '4-6 weeks'
    },
    {
      id: 'battery-addon',
      name: 'Battery Storage Add-on',
      basePrice: 12000,
      currentPrice: 12000,
      description: 'Standalone battery storage system',
      features: ['10kWh Capacity', 'Smart inverter', '15-year warranty', 'Grid-tie capable'],
      trend: 'stable',
      availability: 'low',
      estimatedInstallTime: '1-2 weeks'
    }
  ];

  useEffect(() => {
    // Simulate real-time data fetching
    const fetchPricing = () => {
      setLoading(true);
      
      // Simulate API delay
      setTimeout(() => {
        // Add some random price fluctuations to simulate real-time changes
        const updatedServices = mockServices.map(service => ({
          ...service,
          currentPrice: service.id === 'residential-average' ? 15000 : service.basePrice + (Math.random() - 0.5) * 2000,
          trend: Math.random() > 0.6 ? 'up' : Math.random() > 0.3 ? 'down' : 'stable' as 'up' | 'down' | 'stable'
        }));
        
        setServices(updatedServices);
        setLastUpdate(new Date());
        setLoading(false);
      }, 1000);
    };

    fetchPricing();

    // Set up real-time updates every 30 seconds
    const interval = setInterval(fetchPricing, 30000);

    return () => clearInterval(interval);
  }, []);

  const filteredServices = services.filter(service =>
    service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    service.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleRequestQuote = (serviceId: string, serviceName: string, price: number) => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to request a quote.",
        variant: "destructive",
        action: (
          <ToastAction altText="Login" onClick={() => navigate('/login')}>
            Login
          </ToastAction>
        )
      });
      return;
    }

    setQuoteRequested(serviceId);

    // Simulate quote processing
    setTimeout(() => {
      toast({
        title: "Quote Requested Successfully!",
        description: `Your quote for ${serviceName} at $${price.toLocaleString()} has been submitted. A solar specialist will contact you within 24 hours.`,
      });
      
      // Show installation completion for the average home package
      if (serviceId === 'residential-average') {
        setTimeout(() => {
          toast({
            title: "Installation Complete!",
            description: "Your solar installation has been scheduled and will be completed within 2-3 weeks. You'll save an estimated $2,000+ annually.",
          });
        }, 2000);
      }
      
      setQuoteRequested(null);
    }, 1500);
  };

  const handleSaveCalculation = (service: ServicePlan) => {
    if (!isAuthenticated) {
      toast({
        title: "Please Sign Up or Login",
        description: "Create an account to save your calculations and access premium features.",
        action: (
          <ToastAction altText="Sign Up" onClick={() => navigate('/register')}>
            Sign Up
          </ToastAction>
        )
      });
      return;
    }

    toast({
      title: "Calculation Saved!",
      description: `${service.name} quote saved to your account.`,
    });
  };

  const handleGeneratePDF = (service: ServicePlan) => {
    if (!isAuthenticated) {
      toast({
        title: "Please Sign Up or Login",
        description: "Create an account to generate PDF reports.",
        action: (
          <ToastAction altText="Sign Up" onClick={() => navigate('/register')}>
            Sign Up
          </ToastAction>
        )
      });
      return;
    }

    toast({
      title: "Generating PDF Report...",
      description: "Your solar quote report will download shortly.",
    });

    setTimeout(() => {
      const pdfContent = generatePDFContent(service);
      downloadPDF(pdfContent, `solar-quote-${service.name.replace(/\s+/g, '-').toLowerCase()}-${new Date().toISOString().split('T')[0]}.pdf`);
    }, 1500);
  };

  const generatePDFContent = (service: ServicePlan) => {
    return `
SOLAR ENERGY QUOTE REPORT
Generated on: ${new Date().toLocaleDateString()}
Generated by: Sunalyzer Solar Calculator

SERVICE DETAILS:
- Service: ${service.name}
- Price: $${service.currentPrice.toLocaleString()}
- Original Price: $${service.basePrice.toLocaleString()}
- Savings: $${(service.basePrice - service.currentPrice).toLocaleString()}
- Installation Time: ${service.estimatedInstallTime}
- Availability: ${service.availability}

FEATURES INCLUDED:
${service.features.map(feature => `- ${feature}`).join('\n')}

DESCRIPTION:
${service.description}

This quote is valid for 30 days from the date of generation.
Contact us at privacy.sunalyzer@gmail.com for more information.

Generated by Sunalyzer - Your Solar Energy Calculator
`;
  };

  const downloadPDF = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "PDF Downloaded Successfully!",
      description: `Quote report saved as ${filename}`,
    });
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="h-4 w-4 text-red-500" />;
      case 'down':
        return <TrendingDown className="h-4 w-4 text-green-500" />;
      default:
        return <div className="h-4 w-4 bg-gray-400 rounded-full" />;
    }
  };

  const getAvailabilityColor = (availability: string) => {
    switch (availability) {
      case 'high':
        return 'bg-green-500';
      case 'medium':
        return 'bg-yellow-500';
      case 'low':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Real-Time Solar Pricing</h2>
          <p className="text-muted-foreground">
            Last updated: {lastUpdate.toLocaleTimeString()}
          </p>
        </div>
        
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search solar services..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredServices.map((service, index) => (
          <motion.div
            key={service.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className={`h-full hover:shadow-lg transition-shadow ${service.isInstallationComplete ? 'border-green-500 bg-green-50' : ''}`}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center gap-2">
                    {service.name}
                    {service.isInstallationComplete && <CheckCircle className="h-5 w-5 text-green-600" />}
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    {getTrendIcon(service.trend)}
                    <div className={`w-2 h-2 rounded-full ${getAvailabilityColor(service.availability)}`} />
                  </div>
                </div>
                <CardDescription>{service.description}</CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4 text-green-600" />
                      <span className="text-2xl font-bold">
                        ${service.currentPrice.toLocaleString()}
                      </span>
                    </div>
                    {service.currentPrice !== service.basePrice && (
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-sm text-muted-foreground line-through">
                          ${service.basePrice.toLocaleString()}
                        </span>
                        <Badge variant="default" className="text-xs">
                          Save ${(service.basePrice - service.currentPrice).toLocaleString()}
                        </Badge>
                      </div>
                    )}
                  </div>
                  <Badge variant={service.trend === 'down' ? 'default' : 'secondary'}>
                    {service.trend === 'down' ? 'Save Now' : 
                     service.trend === 'up' ? 'High Demand' : 'Stable'}
                  </Badge>
                </div>

                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    Install Time: {service.estimatedInstallTime}
                  </p>
                  <ul className="text-sm space-y-1">
                    {service.features.slice(0, 3).map((feature, idx) => (
                      <li key={idx} className="flex items-center">
                        <div className="w-1.5 h-1.5 bg-green-500 rounded-full mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2">
                  <Button 
                    className="w-full" 
                    onClick={() => handleRequestQuote(service.id, service.name, service.currentPrice)}
                    disabled={loading || quoteRequested === service.id}
                    variant={service.isInstallationComplete ? "default" : "outline"}
                  >
                    {quoteRequested === service.id ? "Processing..." : "Request Quote"}
                  </Button>

                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="flex-1 flex items-center gap-1"
                      onClick={() => handleSaveCalculation(service)}
                    >
                      {isAuthenticated ? <Save className="h-3 w-3" /> : <LogIn className="h-3 w-3" />}
                      {isAuthenticated ? 'Save' : 'Sign Up'}
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="flex-1 flex items-center gap-1"
                      onClick={() => handleGeneratePDF(service)}
                    >
                      <Download className="h-3 w-3" />
                      PDF
                    </Button>
                  </div>
                </div>

                {service.isInstallationComplete && (
                  <div className="bg-green-100 p-3 rounded-lg">
                    <p className="text-sm font-medium text-green-800">
                      ✓ Installation Package Complete - Ready to Install!
                    </p>
                    <p className="text-xs text-green-600 mt-1">
                      Everything included for your average home solar installation
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {filteredServices.length === 0 && !loading && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No services found matching your search.</p>
        </div>
      )}
    </div>
  );
};

export default RealTimePricing;

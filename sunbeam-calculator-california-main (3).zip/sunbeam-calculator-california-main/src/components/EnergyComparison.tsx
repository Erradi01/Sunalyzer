
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Zap, Leaf, DollarSign, TrendingDown, Calculator } from 'lucide-react';
import { motion } from 'framer-motion';

interface EnergyComparisonProps {
  className?: string;
}

const EnergyComparison: React.FC<EnergyComparisonProps> = ({ className }) => {
  const [monthlyBill, setMonthlyBill] = useState(150);
  const [usage, setUsage] = useState(1000);
  const [location, setLocation] = useState('California');

  const calculateComparison = () => {
    const gridCostPerKwh = 0.27;
    const solarCostPerKwh = 0.08;
    const annualSavings = (gridCostPerKwh - solarCostPerKwh) * usage * 12;
    const co2Reduction = usage * 12 * 0.0004; // tons of CO2 per year
    const paybackPeriod = 15000 / annualSavings; // assuming $15k system cost

    return {
      gridCost: gridCostPerKwh * usage,
      solarCost: solarCostPerKwh * usage,
      monthlySavings: (gridCostPerKwh - solarCostPerKwh) * usage,
      annualSavings,
      co2Reduction,
      paybackPeriod
    };
  };

  const comparison = calculateComparison();

  return (
    <div className={`max-w-6xl mx-auto ${className}`}>
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-4">Compare Energy Sources</h2>
        <p className="text-muted-foreground text-lg">
          See how solar energy compares to traditional grid electricity
        </p>
      </div>

      <Tabs defaultValue="calculator" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="calculator">Calculator</TabsTrigger>
          <TabsTrigger value="comparison">Detailed Comparison</TabsTrigger>
          <TabsTrigger value="environmental">Environmental Impact</TabsTrigger>
        </TabsList>

        <TabsContent value="calculator">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Energy Usage Calculator
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="monthly-bill">Monthly Electric Bill ($)</Label>
                  <Input
                    id="monthly-bill"
                    type="number"
                    value={monthlyBill}
                    onChange={(e) => setMonthlyBill(Number(e.target.value))}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="monthly-usage">Monthly Usage (kWh)</Label>
                  <Input
                    id="monthly-usage"
                    type="number"
                    value={usage}
                    onChange={(e) => setUsage(Number(e.target.value))}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="mt-1"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Cost Comparison
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Grid Electricity</span>
                    <span className="font-bold text-red-600">${comparison.gridCost.toFixed(2)}/month</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Solar Energy</span>
                    <span className="font-bold text-green-600">${comparison.solarCost.toFixed(2)}/month</span>
                  </div>
                  <div className="border-t pt-4">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">Monthly Savings</span>
                      <span className="font-bold text-green-600">${comparison.monthlySavings.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">Annual Savings</span>
                      <span className="font-bold text-green-600">${comparison.annualSavings.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="comparison">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card className="h-full">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-red-600">
                    <Zap className="h-5 w-5" />
                    Grid Electricity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between">
                        <span>Cost per kWh</span>
                        <span>$0.27</span>
                      </div>
                      <Progress value={100} className="mt-2 h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between">
                        <span>Price Stability</span>
                        <span>Low</span>
                      </div>
                      <Progress value={30} className="mt-2 h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between">
                        <span>Environmental Impact</span>
                        <span>High</span>
                      </div>
                      <Progress value={80} className="mt-2 h-2 bg-red-100" />
                    </div>
                    <div>
                      <div className="flex justify-between">
                        <span>Energy Independence</span>
                        <span>None</span>
                      </div>
                      <Progress value={0} className="mt-2 h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="h-full border-green-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-green-600">
                    <Leaf className="h-5 w-5" />
                    Solar Energy
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between">
                        <span>Cost per kWh</span>
                        <span>$0.08</span>
                      </div>
                      <Progress value={30} className="mt-2 h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between">
                        <span>Price Stability</span>
                        <span>High</span>
                      </div>
                      <Progress value={95} className="mt-2 h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between">
                        <span>Environmental Impact</span>
                        <span>Minimal</span>
                      </div>
                      <Progress value={10} className="mt-2 h-2 bg-green-100" />
                    </div>
                    <div>
                      <div className="flex justify-between">
                        <span>Energy Independence</span>
                        <span>Complete</span>
                      </div>
                      <Progress value={100} className="mt-2 h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </TabsContent>

        <TabsContent value="environmental">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Leaf className="h-5 w-5" />
                Environmental Impact
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    {comparison.co2Reduction.toFixed(1)} tons
                  </div>
                  <p className="text-sm text-muted-foreground">CO₂ reduction per year</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">
                    {(comparison.co2Reduction * 2500).toFixed(0)}
                  </div>
                  <p className="text-sm text-muted-foreground">Miles of driving offset</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    {(comparison.co2Reduction * 16).toFixed(0)}
                  </div>
                  <p className="text-sm text-muted-foreground">Trees planted equivalent</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-8 text-center">
        <Button size="lg" className="mx-2">
          Get Solar Quote
        </Button>
        <Button variant="outline" size="lg" className="mx-2">
          Learn More
        </Button>
      </div>
    </div>
  );
};

export default EnergyComparison;

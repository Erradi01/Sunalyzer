
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Calendar, FileText, Code, Phone, Settings, Star } from 'lucide-react';
import { toast } from 'sonner';

interface ProfessionalFeaturesProps {
  userTier: string;
}

const ProfessionalFeatures: React.FC<ProfessionalFeaturesProps> = ({ userTier }) => {
  const [apiKey, setApiKey] = useState('');
  const [consultationRequest, setConsultationRequest] = useState('');

  const generateApiKey = () => {
    const newApiKey = `sk_live_${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`;
    setApiKey(newApiKey);
    toast.success('API Key generated successfully!', {
      description: 'Your new API key is ready to use.',
    });
  };

  const requestConsultation = () => {
    if (!consultationRequest.trim()) {
      toast.error('Please describe your consultation needs');
      return;
    }
    toast.success('Consultation request submitted!', {
      description: 'Our expert will contact you within 24 hours.',
    });
    setConsultationRequest('');
  };

  const isProfessional = userTier === 'professional';

  return (
    <div className="space-y-6">
      {/* Professional Badge */}
      <div className="flex items-center gap-2">
        <Star className="h-6 w-6 text-yellow-500 fill-yellow-500" />
        <h2 className="text-2xl font-bold">Professional Features</h2>
        <Badge variant="default" className="bg-gradient-to-r from-purple-500 to-blue-500">
          PRO
        </Badge>
      </div>

      {/* Advanced System Design */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Advanced System Design Options
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Custom Panel Configuration</Label>
              <Input 
                placeholder="Enter panel specifications" 
                disabled={!isProfessional}
              />
            </div>
            <div>
              <Label>Inverter Type Selection</Label>
              <Input 
                placeholder="Micro/String/Power optimizers" 
                disabled={!isProfessional}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Roof Complexity Factor</Label>
              <Input 
                placeholder="1.0 - 2.5" 
                disabled={!isProfessional}
              />
            </div>
            <div>
              <Label>Local Incentive Rate (%)</Label>
              <Input 
                placeholder="Custom incentive rate" 
                disabled={!isProfessional}
              />
            </div>
          </div>
          {!isProfessional && (
            <p className="text-sm text-muted-foreground">
              Upgrade to Professional to access advanced system design options.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Professional PDF Reports */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Professional PDF Reports
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span>Custom Company Branding</span>
              <Badge variant={isProfessional ? "default" : "secondary"}>
                {isProfessional ? "Available" : "Pro Only"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Detailed Financial Analysis</span>
              <Badge variant={isProfessional ? "default" : "secondary"}>
                {isProfessional ? "Available" : "Pro Only"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Performance Projections (25 years)</span>
              <Badge variant={isProfessional ? "default" : "secondary"}>
                {isProfessional ? "Available" : "Pro Only"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Maintenance Schedule</span>
              <Badge variant={isProfessional ? "default" : "secondary"}>
                {isProfessional ? "Available" : "Pro Only"}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* API Access */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Code className="h-5 w-5" />
            API Access
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Your API Key</Label>
            <div className="flex gap-2">
              <Input 
                value={apiKey || (isProfessional ? 'Click generate to create API key' : 'Professional plan required')}
                readOnly
                className="font-mono text-sm"
              />
              <Button 
                onClick={generateApiKey}
                disabled={!isProfessional}
                variant="outline"
              >
                Generate
              </Button>
            </div>
          </div>
          <div className="text-sm text-muted-foreground">
            <p>API Endpoints Available:</p>
            <ul className="list-disc list-inside space-y-1 mt-2">
              <li>/api/calculate - Solar calculation endpoint</li>
              <li>/api/locations - Available locations</li>
              <li>/api/reports - Generate PDF reports</li>
              <li>/api/save - Save calculation results</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Expert Consultation */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Phone className="h-5 w-5" />
            Expert Consultation Calls
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Request Consultation</Label>
            <Textarea
              placeholder="Describe your solar project needs, technical questions, or consultation requirements..."
              value={consultationRequest}
              onChange={(e) => setConsultationRequest(e.target.value)}
              disabled={!isProfessional}
              rows={4}
            />
          </div>
          <Button 
            onClick={requestConsultation}
            disabled={!isProfessional}
            className="w-full"
          >
            <Calendar className="h-4 w-4 mr-2" />
            Schedule Consultation Call
          </Button>
          {isProfessional && (
            <div className="text-sm text-muted-foreground">
              <p>✓ 30-minute monthly consultation included</p>
              <p>✓ Expert solar engineers available</p>
              <p>✓ Custom system design review</p>
              <p>✓ ROI optimization strategies</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfessionalFeatures;

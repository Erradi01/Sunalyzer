
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Save, Download, MapPin, MessageCircle, Star } from 'lucide-react';
import { toast } from 'sonner';

interface BasicFeaturesProps {
  userTier: string;
  savedCalculations?: number;
}

const BasicFeatures: React.FC<BasicFeaturesProps> = ({ 
  userTier, 
  savedCalculations = 0 
}) => {
  const [exportingPdf, setExportingPdf] = useState(false);

  const isBasicOrHigher = ['basic', 'professional', 'enterprise'].includes(userTier);
  const maxSavedCalculations = 10;
  const usagePercentage = (savedCalculations / maxSavedCalculations) * 100;

  const exportBasicPdf = async () => {
    if (!isBasicOrHigher) {
      toast.error('Basic plan required for PDF export');
      return;
    }
    
    setExportingPdf(true);
    // Simulate PDF generation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    toast.success('Basic PDF report exported!', {
      description: 'Your solar calculation report has been downloaded.',
    });
    setExportingPdf(false);
  };

  const accessPriorityCommunity = () => {
    if (!isBasicOrHigher) {
      toast.error('Basic plan required for priority community support');
      return;
    }
    
    toast.success('Accessing priority community support!', {
      description: 'You now have access to priority help and faster response times.',
    });
  };

  return (
    <div className="space-y-6">
      {/* Basic Plan Badge */}
      <div className="flex items-center gap-2">
        <Star className="h-6 w-6 text-blue-500 fill-blue-500" />
        <h2 className="text-2xl font-bold">Basic Plan Features</h2>
        <Badge variant="outline" className="border-blue-500 text-blue-500">
          BASIC
        </Badge>
      </div>

      {/* Saved Calculations Limit */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Save className="h-5 w-5" />
            Save Up to 10 Calculations
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Saved Calculations</span>
              <span>{savedCalculations} / {maxSavedCalculations}</span>
            </div>
            <Progress value={usagePercentage} className="h-2" />
          </div>
          <div className="text-sm text-muted-foreground">
            {isBasicOrHigher ? (
              <p>You can save and organize your solar calculations for future reference.</p>
            ) : (
              <p>Upgrade to Basic plan to save your calculations.</p>
            )}
          </div>
          {usagePercentage >= 80 && isBasicOrHigher && (
            <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">
                You're approaching your saved calculations limit. Consider upgrading to Professional for unlimited saves.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Basic PDF Export */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Export Basic PDF Reports
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span>System Overview Report</span>
              <Badge variant={isBasicOrHigher ? "default" : "secondary"}>
                {isBasicOrHigher ? "Available" : "Basic Plan Required"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Cost & Savings Summary</span>
              <Badge variant={isBasicOrHigher ? "default" : "secondary"}>
                {isBasicOrHigher ? "Available" : "Basic Plan Required"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Installation Timeline</span>
              <Badge variant={isBasicOrHigher ? "default" : "secondary"}>
                {isBasicOrHigher ? "Available" : "Basic Plan Required"}
              </Badge>
            </div>
          </div>
          <Button 
            onClick={exportBasicPdf}
            disabled={!isBasicOrHigher || exportingPdf}
            className="w-full"
          >
            <Download className="h-4 w-4 mr-2" />
            {exportingPdf ? 'Generating PDF...' : 'Export Basic PDF Report'}
          </Button>
        </CardContent>
      </Card>

      {/* Additional Locations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Additional Locations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span>USA Regions (All States)</span>
              <Badge variant={isBasicOrHigher ? "default" : "secondary"}>
                {isBasicOrHigher ? "Available" : "Basic Plan Required"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>European Cities</span>
              <Badge variant={isBasicOrHigher ? "default" : "secondary"}>
                {isBasicOrHigher ? "Available" : "Basic Plan Required"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Weather Data Integration</span>
              <Badge variant={isBasicOrHigher ? "default" : "secondary"}>
                {isBasicOrHigher ? "Available" : "Basic Plan Required"}
              </Badge>
            </div>
          </div>
          {isBasicOrHigher && (
            <div className="mt-4 text-sm text-muted-foreground">
              <p>✓ Access to 100+ cities across USA and Europe</p>
              <p>✓ Accurate solar irradiance data</p>
              <p>✓ Local utility rate information</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Priority Community Support */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5" />
            Priority Community Support
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span>Priority Response Time</span>
              <Badge variant={isBasicOrHigher ? "default" : "secondary"}>
                {isBasicOrHigher ? "< 4 hours" : "Basic Plan Required"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Expert Community Access</span>
              <Badge variant={isBasicOrHigher ? "default" : "secondary"}>
                {isBasicOrHigher ? "Available" : "Basic Plan Required"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Installation Tips & Guides</span>
              <Badge variant={isBasicOrHigher ? "default" : "secondary"}>
                {isBasicOrHigher ? "Available" : "Basic Plan Required"}
              </Badge>
            </div>
          </div>
          <Button 
            onClick={accessPriorityCommunity}
            disabled={!isBasicOrHigher}
            className="w-full"
            variant="outline"
          >
            <MessageCircle className="h-4 w-4 mr-2" />
            Access Priority Community
          </Button>
          {isBasicOrHigher && (
            <div className="text-sm text-muted-foreground">
              <p>✓ Direct access to solar experts</p>
              <p>✓ Faster response times</p>
              <p>✓ Exclusive installation guides</p>
              <p>✓ Peer-to-peer learning community</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default BasicFeatures;


import React from 'react';
import { useFirebaseAuth } from '@/contexts/FirebaseAuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Crown, Star, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import FreeFeatures from './FreeFeatures';
import BasicFeatures from './BasicFeatures';
import ProfessionalFeatures from './ProfessionalFeatures';

const SubscriptionManager: React.FC = () => {
  const { user } = useFirebaseAuth();
  const navigate = useNavigate();
  
  const userTier = user?.subscriptionTier || 'free';
  const savedCalculations = 3; // This would come from actual data

  const getPlanIcon = (tier: string) => {
    switch (tier) {
      case 'professional':
        return <Crown className="h-5 w-5 text-purple-500" />;
      case 'basic':
        return <Star className="h-5 w-5 text-blue-500" />;
      default:
        return <Zap className="h-5 w-5 text-gray-500" />;
    }
  };

  const getPlanColor = (tier: string) => {
    switch (tier) {
      case 'professional':
        return 'bg-gradient-to-r from-purple-500 to-blue-500';
      case 'basic':
        return 'bg-gradient-to-r from-blue-500 to-cyan-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Current Plan Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            {getPlanIcon(userTier)}
            <span>Current Subscription Plan</span>
            <Badge className={getPlanColor(userTier)}>
              {userTier.charAt(0).toUpperCase() + userTier.slice(1)}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center">
            <div>
              <p className="text-lg font-semibold">
                {userTier === 'professional' && 'Professional Plan - $29.99/month'}
                {userTier === 'basic' && 'Basic Plan - $9.99/month'}
                {userTier === 'free' && 'Free Plan - $0/month'}
              </p>
              <p className="text-muted-foreground">
                {userTier === 'professional' && 'Advanced tools for serious solar enthusiasts'}
                {userTier === 'basic' && 'Perfect for homeowners exploring solar options'}
                {userTier === 'free' && 'Get started with basic solar calculations'}
              </p>
            </div>
            {userTier === 'free' && (
              <Button onClick={() => navigate('/saas-plans')}>
                Upgrade Plan
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Plan Features */}
      {userTier === 'free' && (
        <FreeFeatures 
          userTier={userTier}
        />
      )}

      {(userTier === 'basic' || userTier === 'professional' || userTier === 'enterprise') && (
        <BasicFeatures 
          userTier={userTier} 
          savedCalculations={savedCalculations}
        />
      )}

      {(userTier === 'professional' || userTier === 'enterprise') && (
        <ProfessionalFeatures userTier={userTier} />
      )}

      {/* Upgrade Prompt for Free Users */}
      {userTier === 'free' && (
        <Card className="border-dashed border-2 border-primary/50">
          <CardContent className="text-center py-8">
            <h3 className="text-xl font-bold mb-2">Unlock More Features</h3>
            <p className="text-muted-foreground mb-4">
              Upgrade to access saved calculations, PDF reports, and more locations
            </p>
            <div className="flex justify-center gap-4">
              <Button 
                variant="outline" 
                onClick={() => navigate('/saas-plans')}
              >
                View Plans
              </Button>
              <Button onClick={() => navigate('/saas-plans')}>
                Upgrade Now
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default SubscriptionManager;


import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calculator, MapPin, Settings, Users, Lock } from 'lucide-react';
import { toast } from 'sonner';

interface FreeFeaturesProps {
  userTier: string;
}

const FreeFeatures: React.FC<FreeFeaturesProps> = ({ userTier }) => {
  const [calculationsUsed] = useState(2); // This would come from actual data
  const maxCalculations = 3; // Free tier limit

  const isFree = userTier === 'free';

  return (
    <div className="space-y-6">
      {/* Free Plan Badge */}
      <div className="flex items-center gap-2">
        <Calculator className="h-6 w-6 text-green-500" />
        <h2 className="text-2xl font-bold">Free Plan Features</h2>
        <Badge variant="secondary" className="bg-green-100 text-green-800">
          FREE
        </Badge>
      </div>

      {/* Basic Solar Calculator */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Basic Solar Calculator
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center justify-between">
              <span>Daily Energy Calculation</span>
              <Badge variant="default">Available</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Basic System Sizing</span>
              <Badge variant="default">Available</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Cost Estimation</span>
              <Badge variant="default">Available</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Payback Period</span>
              <Badge variant="default">Available</Badge>
            </div>
          </div>
          <div className="p-4 bg-green-50 rounded-lg">
            <h4 className="font-medium text-green-800 mb-2">What's Included:</h4>
            <ul className="text-sm space-y-1 text-green-700">
              <li>• Basic panel and inverter calculations</li>
              <li>• Standard efficiency ratings</li>
              <li>• Federal tax credit estimates</li>
              <li>• Simple ROI calculations</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* California Locations Only */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Location Coverage
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span>California Regions</span>
              <Badge variant="default">Available</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>USA Nationwide</span>
              <Badge variant="secondary" className="bg-gray-100">
                <Lock className="h-3 w-3 mr-1" />
                Premium Only
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>European Locations</span>
              <Badge variant="secondary" className="bg-gray-100">
                <Lock className="h-3 w-3 mr-1" />
                Premium Only
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Worldwide Coverage</span>
              <Badge variant="secondary" className="bg-gray-100">
                <Lock className="h-3 w-3 mr-1" />
                Professional Only
              </Badge>
            </div>
          </div>
          <div className="mt-4 p-4 bg-blue-50 rounded-lg">
            <h4 className="font-medium text-blue-800 mb-2">Available California Regions:</h4>
            <div className="grid grid-cols-2 gap-2 text-sm text-blue-700">
              <span>• San Francisco Bay Area</span>
              <span>• Los Angeles</span>
              <span>• San Diego</span>
              <span>• Central Valley</span>
              <span>• Sacramento</span>
              <span>• Orange County</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Standard Panel Options */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Panel & System Options
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span>Standard Efficiency Panels</span>
              <Badge variant="default">Available</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>High Efficiency Panels</span>
              <Badge variant="secondary" className="bg-gray-100">
                <Lock className="h-3 w-3 mr-1" />
                Premium Only
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Premium Panels</span>
              <Badge variant="secondary" className="bg-gray-100">
                <Lock className="h-3 w-3 mr-1" />
                Professional Only
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Battery Storage Options</span>
              <Badge variant="default">Basic</Badge>
            </div>
          </div>
          <div className="mt-4 p-4 bg-yellow-50 rounded-lg">
            <h4 className="font-medium text-yellow-800 mb-2">Standard Options Include:</h4>
            <ul className="text-sm space-y-1 text-yellow-700">
              <li>• 300W - 350W monocrystalline panels</li>
              <li>• String inverters</li>
              <li>• Basic mounting systems</li>
              <li>• Standard warranty coverage</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Community Access */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Community Access
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span>Community Forums</span>
              <Badge variant="default">Available</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Basic Support</span>
              <Badge variant="default">Available</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Priority Support</span>
              <Badge variant="secondary" className="bg-gray-100">
                <Lock className="h-3 w-3 mr-1" />
                Premium Only
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Expert Consultation</span>
              <Badge variant="secondary" className="bg-gray-100">
                <Lock className="h-3 w-3 mr-1" />
                Professional Only
              </Badge>
            </div>
          </div>
          <Button 
            className="w-full mt-4" 
            variant="outline"
            onClick={() => toast.info('Community features coming soon!')}
          >
            <Users className="h-4 w-4 mr-2" />
            Access Community
          </Button>
        </CardContent>
      </Card>

      {/* Usage Limits */}
      <Card>
        <CardHeader>
          <CardTitle>Usage Limits</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span>Calculations Used</span>
                <span className="font-medium">{calculationsUsed}/{maxCalculations}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-green-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(calculationsUsed / maxCalculations) * 100}%` }}
                />
              </div>
            </div>
            <div className="text-sm text-muted-foreground">
              <p>• Reset monthly on the 1st</p>
              <p>• Upgrade for unlimited calculations</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FreeFeatures;


import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  MessageSquare, 
  ThumbsUp, 
  ThumbsDown, 
  Star, 
  Search,
  Plus,
  TrendingUp,
  Users,
  Award,
  Filter
} from 'lucide-react';
import { useFirebaseAuth } from '@/contexts/FirebaseAuthContext';
import { toast } from 'sonner';

interface Question {
  id: string;
  title: string;
  content: string;
  author: {
    name: string;
    avatar?: string;
    reputation: number;
    badge?: string;
  };
  tags: string[];
  votes: number;
  answers: number;
  views: number;
  createdAt: string;
  isAnswered: boolean;
}

interface Answer {
  id: string;
  content: string;
  author: {
    name: string;
    avatar?: string;
    reputation: number;
  };
  votes: number;
  isAccepted: boolean;
  createdAt: string;
}

const Community: React.FC = () => {
  const { user, isAuthenticated } = useFirebaseAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState('');
  const [showNewQuestionForm, setShowNewQuestionForm] = useState(false);
  const [newQuestion, setNewQuestion] = useState({
    title: '',
    content: '',
    tags: ''
  });

  // Mock data
  const questions: Question[] = [
    {
      id: '1',
      title: 'What\'s the best solar panel efficiency for residential use?',
      content: 'I\'m considering installing solar panels on my home. What efficiency rating should I look for?',
      author: {
        name: 'John Solar',
        reputation: 1250,
        badge: 'Expert'
      },
      tags: ['solar-panels', 'efficiency', 'residential'],
      votes: 15,
      answers: 3,
      views: 234,
      createdAt: '2 hours ago',
      isAnswered: true
    },
    {
      id: '2',
      title: 'Solar installation cost in California vs other states?',
      content: 'Comparing solar installation costs across different states. Any insights?',
      author: {
        name: 'Energy Enthusiast',
        reputation: 890,
      },
      tags: ['cost', 'california', 'installation'],
      votes: 8,
      answers: 1,
      views: 156,
      createdAt: '5 hours ago',
      isAnswered: false
    },
    {
      id: '3',
      title: 'Battery storage: Tesla vs other alternatives?',
      content: 'Looking into battery storage options for my solar system. What are the pros and cons?',
      author: {
        name: 'Green Power',
        reputation: 650,
      },
      tags: ['battery', 'storage', 'tesla'],
      votes: 12,
      answers: 5,
      views: 423,
      createdAt: '1 day ago',
      isAnswered: true
    }
  ];

  const topTags = [
    { name: 'solar-panels', count: 156 },
    { name: 'installation', count: 89 },
    { name: 'cost', count: 76 },
    { name: 'efficiency', count: 54 },
    { name: 'battery', count: 43 },
    { name: 'maintenance', count: 32 }
  ];

  const topUsers = [
    { name: 'Dr. Solar Expert', reputation: 5450, answers: 89, badge: 'Guru' },
    { name: 'Installation Pro', reputation: 3210, answers: 67, badge: 'Expert' },
    { name: 'Energy Saver', reputation: 2890, answers: 45, badge: 'Expert' }
  ];

  const handleSubmitQuestion = () => {
    if (!isAuthenticated) {
      toast.error('Please log in to ask a question');
      return;
    }

    if (!newQuestion.title.trim() || !newQuestion.content.trim()) {
      toast.error('Please fill in all required fields');
      return;
    }

    toast.success('Question submitted successfully!');
    setNewQuestion({ title: '', content: '', tags: '' });
    setShowNewQuestionForm(false);
  };

  const filteredQuestions = questions.filter(q => 
    q.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    q.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (selectedTag && q.tags.includes(selectedTag))
  );

  return (
    <div className="container px-4 py-8 mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Solar Community</h1>
        <p className="text-muted-foreground">
          Connect with solar experts and enthusiasts. Ask questions, share knowledge, and learn together.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-3 space-y-6">
          {/* Search and Filters */}
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search questions..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Button onClick={() => setShowNewQuestionForm(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Ask Question
                </Button>
              </div>
              
              {selectedTag && (
                <div className="mt-3 flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Filtered by:</span>
                  <Badge variant="secondary" className="cursor-pointer" onClick={() => setSelectedTag('')}>
                    {selectedTag} ×
                  </Badge>
                </div>
              )}
            </CardContent>
          </Card>

          {/* New Question Form */}
          {showNewQuestionForm && (
            <Card>
              <CardHeader>
                <CardTitle>Ask a Question</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Question Title</label>
                  <Input
                    placeholder="What's your solar question?"
                    value={newQuestion.title}
                    onChange={(e) => setNewQuestion({ ...newQuestion, title: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Details</label>
                  <Textarea
                    placeholder="Provide more details about your question..."
                    value={newQuestion.content}
                    onChange={(e) => setNewQuestion({ ...newQuestion, content: e.target.value })}
                    rows={4}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Tags (comma separated)</label>
                  <Input
                    placeholder="solar-panels, installation, cost"
                    value={newQuestion.tags}
                    onChange={(e) => setNewQuestion({ ...newQuestion, tags: e.target.value })}
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={handleSubmitQuestion}>Submit Question</Button>
                  <Button variant="outline" onClick={() => setShowNewQuestionForm(false)}>
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Questions List */}
          <div className="space-y-4">
            {filteredQuestions.map((question) => (
              <Card key={question.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="flex flex-col items-center gap-2 min-w-[80px]">
                      <div className="text-center">
                        <div className="text-lg font-bold">{question.votes}</div>
                        <div className="text-xs text-muted-foreground">votes</div>
                      </div>
                      <div className={`text-center p-2 rounded ${question.isAnswered ? 'bg-green-100 text-green-700' : 'bg-muted'}`}>
                        <div className="text-sm font-bold">{question.answers}</div>
                        <div className="text-xs">answers</div>
                      </div>
                      <div className="text-center">
                        <div className="text-sm">{question.views}</div>
                        <div className="text-xs text-muted-foreground">views</div>
                      </div>
                    </div>

                    <div className="flex-1">
                      <h3 className="text-lg font-semibold mb-2 hover:text-primary cursor-pointer">
                        {question.title}
                      </h3>
                      <p className="text-muted-foreground mb-3 line-clamp-2">
                        {question.content}
                      </p>
                      
                      <div className="flex flex-wrap gap-2 mb-3">
                        {question.tags.map((tag) => (
                          <Badge 
                            key={tag} 
                            variant="secondary" 
                            className="cursor-pointer hover:bg-primary hover:text-primary-foreground"
                            onClick={() => setSelectedTag(tag)}
                          >
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-6 w-6">
                            <AvatarFallback>{question.author.name[0]}</AvatarFallback>
                          </Avatar>
                          <span className="text-sm font-medium">{question.author.name}</span>
                          {question.author.badge && (
                            <Badge variant="outline" className="text-xs">
                              {question.author.badge}
                            </Badge>
                          )}
                          <span className="text-xs text-muted-foreground">
                            {question.author.reputation} rep
                          </span>
                        </div>
                        <span className="text-xs text-muted-foreground">
                          asked {question.createdAt}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Community Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Community Stats
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span>Questions</span>
                <span className="font-bold">1,234</span>
              </div>
              <div className="flex justify-between">
                <span>Answers</span>
                <span className="font-bold">3,456</span>
              </div>
              <div className="flex justify-between">
                <span>Users</span>
                <span className="font-bold">892</span>
              </div>
              <div className="flex justify-between">
                <span>Expert Answers</span>
                <span className="font-bold">567</span>
              </div>
            </CardContent>
          </Card>

          {/* Popular Tags */}
          <Card>
            <CardHeader>
              <CardTitle>Popular Tags</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {topTags.map((tag) => (
                  <Badge 
                    key={tag.name}
                    variant="secondary" 
                    className="cursor-pointer hover:bg-primary hover:text-primary-foreground"
                    onClick={() => setSelectedTag(tag.name)}
                  >
                    {tag.name} ({tag.count})
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Top Contributors */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5" />
                Top Contributors
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {topUsers.map((user, index) => (
                <div key={user.name} className="flex items-center gap-3">
                  <div className="text-lg font-bold text-muted-foreground">
                    #{index + 1}
                  </div>
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{user.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="font-medium text-sm">{user.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {user.reputation} rep • {user.answers} answers
                    </div>
                  </div>
                  {user.badge && (
                    <Badge variant="default" className="text-xs">
                      {user.badge}
                    </Badge>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Community;

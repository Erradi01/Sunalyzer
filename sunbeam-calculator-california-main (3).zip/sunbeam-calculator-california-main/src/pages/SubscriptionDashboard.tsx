
import React from 'react';
import { useFirebaseAuth } from '@/contexts/FirebaseAuthContext';
import SubscriptionManager from '@/components/subscription/SubscriptionManager';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

const SubscriptionDashboard: React.FC = () => {
  const { isAuthenticated } = useFirebaseAuth();
  const navigate = useNavigate();

  if (!isAuthenticated) {
    navigate('/register');
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate('/dashboard')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
          <h1 className="text-3xl font-bold">Subscription Management</h1>
        </div>
        
        <SubscriptionManager />
      </div>
    </div>
  );
};

export default SubscriptionDashboard;

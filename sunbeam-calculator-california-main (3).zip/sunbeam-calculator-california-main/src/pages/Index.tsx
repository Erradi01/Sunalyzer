
import React from 'react';
import { motion } from "framer-motion";
import { Link } from 'react-router-dom';
import { useFirebaseAuth } from '@/contexts/FirebaseAuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowRight, Calculator, Sun, Book, DollarSign, BadgeCheck, Lightbulb, Quote, Leaf, Trees, Recycle, CloudSun } from 'lucide-react';
import SolarCalculator from '@/components/SolarCalculator';
import SolarImageCarousel from '@/components/SolarImageCarousel';
import RealTimePricing from '@/components/RealTimePricing';

const Index = () => {
  const { isAuthenticated } = useFirebaseAuth();
  
  const scrollToCalculator = () => {
    const calculatorSection = document.getElementById('calculator');
    if (calculatorSection) {
      calculatorSection.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  return (
    <div className="min-h-screen">
      {/* Hero Section with Image Carousel */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-yellow-100 to-blue-50 opacity-50 z-0"></div>
        <div className="container px-4 mx-auto relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h1 className="text-4xl sm:text-5xl font-bold mb-6 font-mono tracking-tight">
                  Make the Switch to <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">Solar Energy</span>
                </h1>
                <p className="text-xl text-zinc-600 mb-8">
                  Calculate your potential savings with our advanced solar calculator and get real-time pricing from certified installers.
                </p>
                <div className="flex flex-wrap gap-4">
                  <a href="#calculator">
                    <Button size="lg" className="gap-2">
                      Try Calculator <Calculator className="h-4 w-4" />
                    </Button>
                  </a>
                  <a href="#pricing">
                    <Button variant="outline" size="lg" className="gap-2">
                      View Pricing <DollarSign className="h-4 w-4" />
                    </Button>
                  </a>
                </div>
              </motion.div>
            </div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="relative"
            >
              <SolarImageCarousel />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Primary Solar Calculator Section */}
      <section id="calculator" className="py-16 bg-gradient-to-br from-zinc-50 to-white">
        <div className="container px-4 mx-auto">
          <div className="text-center mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl font-bold mb-4">Solar Calculator - Our Primary Service</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Get accurate estimates for your solar system size, cost, and savings with our advanced calculator
              </p>
            </motion.div>
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <SolarCalculator />
          </motion.div>
        </div>
      </section>

      {/* Real-Time Service Pricing Section */}
      <section id="pricing" className="py-16 bg-white">
        <div className="container px-4 mx-auto">
          <div className="text-center mb-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl font-bold mb-4">Real-Time Solar Service Pricing</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Get live pricing updates based on current market conditions and installer availability
              </p>
            </motion.div>
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <RealTimePricing />
          </motion.div>
        </div>
      </section>

      {/* Features Section - Calculator Focus */}
      <section className="py-16 bg-gradient-to-br from-zinc-50 to-white">
        <div className="container px-4 mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Our Solar Calculator Stands Out</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Advanced algorithms and real-time data for the most accurate solar estimates
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Card className="border-t-4 border-t-yellow-400 h-full">
                <CardHeader>
                  <Calculator className="h-8 w-8 mb-2 text-yellow-500" />
                  <CardTitle>Real-Time Calculations</CardTitle>
                  <CardDescription>
                    Live data integration with current energy prices and solar panel costs
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  Our calculator uses real-time market data, weather patterns, and local incentives 
                  to provide the most accurate solar estimates available.
                </CardContent>
              </Card>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="border-t-4 border-t-blue-400 h-full">
                <CardHeader>
                  <Lightbulb className="h-8 w-8 mb-2 text-blue-500" />
                  <CardTitle>Smart Recommendations</CardTitle>
                  <CardDescription>
                    AI-powered system sizing and configuration suggestions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  Get personalized recommendations for panel types, battery storage, 
                  and system configurations based on your specific needs and location.
                </CardContent>
              </Card>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Card className="border-t-4 border-t-green-400 h-full">
                <CardHeader>
                  <BadgeCheck className="h-8 w-8 mb-2 text-green-500" />
                  <CardTitle>Verified Results</CardTitle>
                  <CardDescription>
                    Connect with certified installers for quote verification
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  All calculator results can be verified by our network of certified installers 
                  who provide competitive quotes based on your calculations.
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <div className="text-center mt-12">
            <Button size="lg" className="gap-2" onClick={scrollToCalculator}>
              Try Our Advanced Calculator <Calculator className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* Environmental Impact Section */}
      <section className="py-16 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="container px-4 mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Environmental Benefits</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Calculate your environmental impact alongside your financial savings
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="border-green-200 border">
              <CardHeader className="pb-2">
                <div className="bg-green-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-2">
                  <CloudSun className="h-8 w-8 text-green-600" />
                </div>
                <CardTitle className="text-xl">CO₂ Reduction</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Calculate exactly how much CO₂ your solar system will offset over its lifetime.</p>
              </CardContent>
            </Card>
            
            <Card className="border-green-200 border">
              <CardHeader className="pb-2">
                <div className="bg-green-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-2">
                  <Trees className="h-8 w-8 text-green-600" />
                </div>
                <CardTitle className="text-xl">Tree Equivalent</CardTitle>
              </CardHeader>
              <CardContent>
                <p>See how many trees your solar system is equivalent to planting each year.</p>
              </CardContent>
            </Card>
            
            <Card className="border-green-200 border">
              <CardHeader className="pb-2">
                <div className="bg-green-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-2">
                  <Recycle className="h-8 w-8 text-green-600" />
                </div>
                <CardTitle className="text-xl">Water Savings</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Calculate water conservation compared to traditional electricity generation.</p>
              </CardContent>
            </Card>
            
            <Card className="border-green-200 border">
              <CardHeader className="pb-2">
                <div className="bg-green-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-2">
                  <Leaf className="h-8 w-8 text-green-600" />
                </div>
                <CardTitle className="text-xl">Clean Energy</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Track your contribution to clean energy generation in real-time.</p>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-12 text-center">
            <Link to="/#calculator">
              <Button className="gap-2">
                Calculate Your Environmental Impact <Calculator className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary/20 to-secondary/20">
        <div className="container px-4 mx-auto">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Start Your Solar Journey Today</h2>
            <p className="text-lg mb-8">
              Use our advanced calculator to get accurate estimates and connect with certified installers.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a href="#calculator">
                <Button size="lg" className="gap-2">
                  Calculate Now <Calculator className="h-4 w-4" />
                </Button>
              </a>
              <Link to="/service-plans">
                <Button variant="outline" size="lg" className="gap-2">
                  View Service Plans <Lightbulb className="h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;


import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MapPin, DollarSign, Calendar, Users, Search, Plus } from 'lucide-react';
import { useFirebaseAuth } from '@/contexts/FirebaseAuthContext';
import JobPostingForm from '@/components/jobs/JobPostingForm';
import { JOB_URGENCY_LEVELS } from '@/utils/constants';

const JobsMarketplace: React.FC = () => {
  const { user } = useFirebaseAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('browse');

  // Mock jobs data
  const [jobs, setJobs] = useState([
    {
      id: '1',
      title: 'Residential Solar Installation - 10kW System',
      description: 'Looking for a qualified installer to install a 10kW solar system on my single-family home. Property has good sun exposure with minimal shading.',
      category: 'Residential Solar Installation',
      location: 'Los Angeles, CA',
      budget: '20k-30k',
      urgency: 'medium',
      systemSize: '10kW',
      postedAt: '2025-06-07',
      status: 'open',
      proposalCount: 3
    },
    {
      id: '2',
      title: 'Commercial Solar + Battery Storage',
      description: 'Small business looking to install solar panels with battery backup. Need complete turnkey solution including permits and utility interconnection.',
      category: 'Commercial Solar Installation',
      location: 'Phoenix, AZ',
      budget: 'over-50k',
      urgency: 'low',
      systemSize: '25kW',
      postedAt: '2025-06-06',
      status: 'open',
      proposalCount: 7
    }
  ]);

  const getUrgencyColor = (urgency: string) => {
    const level = JOB_URGENCY_LEVELS.find(l => l.value === urgency);
    return level?.color || 'bg-gray-100 text-gray-800';
  };

  const getUrgencyLabel = (urgency: string) => {
    const level = JOB_URGENCY_LEVELS.find(l => l.value === urgency);
    return level?.label || urgency;
  };

  const handleJobPosted = (newJob: any) => {
    setJobs([newJob, ...jobs]);
    setActiveTab('browse');
  };

  const filteredJobs = jobs.filter(job =>
    job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    job.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    job.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container px-4 py-8 mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Solar Jobs Marketplace</h1>
        <p className="text-muted-foreground">
          {user?.userType === 'client' 
            ? 'Post your solar project and get quotes from qualified installers'
            : 'Find solar installation projects and grow your business'
          }
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="browse">
            <Search className="h-4 w-4 mr-2" />
            Browse Jobs
          </TabsTrigger>
          {user?.userType === 'client' && (
            <TabsTrigger value="post">
              <Plus className="h-4 w-4 mr-2" />
              Post a Job
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="browse" className="space-y-6">
          <div className="flex gap-4 mb-6">
            <div className="flex-1">
              <Input
                placeholder="Search jobs by title, location, or description..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
          </div>

          <div className="grid gap-6">
            {filteredJobs.map((job) => (
              <Card key={job.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="space-y-2">
                      <CardTitle className="text-xl">{job.title}</CardTitle>
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="secondary">{job.category}</Badge>
                        <Badge className={getUrgencyColor(job.urgency)}>
                          {getUrgencyLabel(job.urgency)}
                        </Badge>
                        {job.systemSize && (
                          <Badge variant="outline">{job.systemSize}</Badge>
                        )}
                      </div>
                    </div>
                    <div className="text-right text-sm text-muted-foreground">
                      Posted {new Date(job.postedAt).toLocaleDateString()}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">{job.description}</p>
                  
                  <div className="flex flex-wrap gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      {job.location}
                    </div>
                    <div className="flex items-center gap-1">
                      <DollarSign className="h-4 w-4" />
                      {job.budget.replace('-', ' - ').replace('k', ',000')}
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      {job.proposalCount} proposals
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button className="flex-1">
                      {user?.userType === 'installer' ? 'Submit Proposal' : 'View Details'}
                    </Button>
                    {user?.userType === 'installer' && (
                      <Button variant="outline">Save Job</Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}

            {filteredJobs.length === 0 && (
              <Card>
                <CardContent className="text-center py-8">
                  <p className="text-muted-foreground">No jobs found matching your search.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {user?.userType === 'client' && (
          <TabsContent value="post">
            <JobPostingForm onJobPosted={handleJobPosted} />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};

export default JobsMarketplace;

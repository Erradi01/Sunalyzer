
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useFirebaseAuth } from '@/contexts/FirebaseAuthContext';
import SolarCalculator from '@/components/SolarCalculator';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Lock, Star, Save, Download, FileText } from 'lucide-react';
import { toast } from 'sonner';
import SavedCalculationsList from '@/components/premium/SavedCalculationsList';

const PremiumCalculator: React.FC = () => {
  const { user, isAuthenticated } = useFirebaseAuth();
  const navigate = useNavigate();
  const isPremiumUser = user?.subscriptionTier && ['basic', 'professional', 'enterprise'].includes(user.subscriptionTier);

  // Redirect free users to the pricing page
  useEffect(() => {
    if (isAuthenticated && !isPremiumUser) {
      toast.error('Premium Calculator requires a paid subscription', {
        description: 'Please upgrade your plan to access premium features.',
        action: {
          label: 'View Plans',
          onClick: () => navigate('/pricing'),
        },
      });
      navigate('/pricing');
    }
  }, [isAuthenticated, isPremiumUser, navigate]);

  // If still loading auth or user is premium, render the calculator
  return (
    <div className="container px-4 py-8 mx-auto">
      <div className="flex flex-col items-start mb-8">
        <div className="flex items-center gap-2 mb-2">
          <h1 className="text-3xl font-bold">Premium Solar Calculator</h1>
          <Star className="h-6 w-6 text-solar-yellow fill-solar-yellow" />
        </div>
        <p className="text-muted-foreground">
          Advanced solar system design with unlimited saved calculations and professional reports
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <SolarCalculator premiumMode={true} />
        </div>
        
        <div className="space-y-6">
          <SavedCalculationsList />
          
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  <h3 className="text-lg font-medium">Generate Reports</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Create professional PDF reports with your company branding to share with clients.
                </p>
                <Button 
                  className="w-full flex items-center gap-2" 
                  variant="outline"
                  onClick={() => toast.info('PDF Report generation coming soon!')}
                >
                  <Download className="h-4 w-4" />
                  Generate PDF Report
                </Button>
              </div>
            </CardContent>
          </Card>
          
          {isPremiumUser && user?.subscriptionTier === 'professional' && (
            <Card>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Professional Features</h3>
                  <ul className="space-y-2 text-sm">
                    <li>• Multi-zone calculations</li>
                    <li>• Advanced shading analysis</li>
                    <li>• Custom utility rate support</li>
                    <li>• White-label PDF reports</li>
                  </ul>
                  <Button className="w-full" variant="default">
                    Access Pro Features
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default PremiumCalculator;

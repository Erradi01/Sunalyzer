
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Newspaper, TrendingUp, Zap, Globe, Search, ExternalLink, Clock, RefreshCw, Play, Users, Wrench, Quote, UserPlus } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';

interface NewsArticle {
  id: string;
  title: string;
  summary: string;
  category: 'solar' | 'wind' | 'battery' | 'policy' | 'technology';
  source: string;
  publishedAt: string;
  url: string;
  trending: boolean;
  imageUrl?: string;
  originalSource?: string;
}

interface VideoContent {
  id: string;
  title: string;
  videoId: string;
  description: string;
  category: string;
}

const EnergyNews: React.FC = () => {
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [realTimeSearch, setRealTimeSearch] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Enhanced mock real-time news data with original sources
  const mockNews: NewsArticle[] = [
    {
      id: '1',
      title: 'Solar Panel Efficiency Reaches Record 47% in Laboratory Tests',
      summary: 'Researchers at MIT have developed a new perovskite-silicon tandem solar cell that achieves unprecedented efficiency levels, potentially revolutionizing the solar industry.',
      category: 'solar',
      source: 'MIT Technology Review',
      publishedAt: '2024-01-15T10:30:00Z',
      url: 'https://www.technologyreview.com/solar-efficiency',
      originalSource: 'https://news.mit.edu/solar-research',
      trending: true,
      imageUrl: '/placeholder.svg'
    },
    {
      id: '2',
      title: 'Global Wind Energy Capacity Grows by 77 GW in 2024',
      summary: 'The Global Wind Energy Council reports significant growth in wind installations worldwide, with offshore wind leading the expansion in renewable energy capacity.',
      category: 'wind',
      source: 'Renewable Energy World',
      publishedAt: '2024-01-15T08:15:00Z',
      url: 'https://www.renewableenergyworld.com/wind-growth',
      originalSource: 'https://gwec.net/global-wind-report-2024',
      trending: false
    },
    {
      id: '3',
      title: 'Tesla Announces Revolutionary 4680 Battery Cell Production Scale-Up',
      summary: 'Tesla plans to dramatically increase production of its advanced 4680 battery cells, promising lower costs and improved energy density for electric vehicles and grid storage.',
      category: 'battery',
      source: 'CleanTechnica',
      publishedAt: '2024-01-14T16:45:00Z',
      url: 'https://cleantechnica.com/tesla-4680-battery',
      originalSource: 'https://ir.tesla.com/battery-day-presentation',
      trending: true
    },
    {
      id: '4',
      title: 'EU Approves €3 Billion Green Energy Investment Package',
      summary: 'The European Union has approved a major investment package to accelerate renewable energy deployment across member states, focusing on solar and wind infrastructure.',
      category: 'policy',
      source: 'Energy Policy News',
      publishedAt: '2024-01-14T12:20:00Z',
      url: 'https://energypolicy.eu/green-investment',
      originalSource: 'https://ec.europa.eu/energy/green-deal',
      trending: false
    },
    {
      id: '5',
      title: 'AI-Powered Smart Grid Technology Reduces Energy Waste by 30%',
      summary: 'New artificial intelligence algorithms are helping utility companies optimize energy distribution, significantly reducing waste and improving grid reliability.',
      category: 'technology',
      source: 'Smart Energy International',
      publishedAt: '2024-01-13T14:30:00Z',
      url: 'https://smartenergyinternational.com/ai-grid',
      originalSource: 'https://www.nrel.gov/smart-grid-research',
      trending: true
    },
    {
      id: '6',
      title: 'Floating Solar Farms Show Promise for Water Conservation',
      summary: 'New studies demonstrate that floating photovoltaic systems not only generate clean energy but also help reduce water evaporation from reservoirs by up to 70%.',
      category: 'solar',
      source: 'Environmental Science Today',
      publishedAt: '2024-01-13T09:15:00Z',
      url: 'https://environmentalscience.org/floating-solar',
      originalSource: 'https://www.sciencedirect.com/floating-pv-study',
      trending: false
    }
  ];

  // YouTube video content about energy and technology
  const videoContent: VideoContent[] = [
    {
      id: '1',
      title: 'The Future of Solar Energy Technology',
      videoId: 'dQw4w9WgXcQ', // Replace with actual video IDs
      description: 'Exploring breakthrough technologies in solar panel efficiency and cost reduction',
      category: 'Solar Technology'
    },
    {
      id: '2',
      title: 'Wind Energy Revolution: Offshore Giants',
      videoId: 'dQw4w9WgXcQ',
      description: 'How massive offshore wind farms are changing the energy landscape',
      category: 'Wind Energy'
    },
    {
      id: '3',
      title: 'Battery Storage: The Key to Renewable Energy',
      videoId: 'dQw4w9WgXcQ',
      description: 'Understanding the critical role of energy storage in the green transition',
      category: 'Energy Storage'
    }
  ];

  useEffect(() => {
    // Enhanced real-time news fetching simulation
    const fetchNews = () => {
      setLoading(true);
      
      setTimeout(() => {
        // Add some randomization to simulate real-time updates
        const updatedNews = mockNews.map(article => ({
          ...article,
          trending: Math.random() > 0.7,
          publishedAt: Math.random() > 0.8 ? new Date().toISOString() : article.publishedAt
        }));
        
        setArticles(updatedNews);
        setLastUpdate(new Date());
        setLoading(false);
      }, 1000);
    };

    fetchNews();
    
    // Update news more frequently when real-time search is enabled
    const interval = setInterval(fetchNews, realTimeSearch ? 60000 : 300000);
    
    return () => clearInterval(interval);
  }, [realTimeSearch]);

  // Real-time search functionality
  useEffect(() => {
    if (realTimeSearch && searchTerm) {
      const searchTimeout = setTimeout(() => {
        // Simulate real-time search API call
        console.log(`Real-time searching for: ${searchTerm}`);
        toast({
          title: "Real-time Search Active",
          description: `Searching for "${searchTerm}" in real-time`,
        });
      }, 500);

      return () => clearTimeout(searchTimeout);
    }
  }, [searchTerm, realTimeSearch, toast]);

  const filteredArticles = articles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.summary.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const trendingArticles = articles.filter(article => article.trending);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'solar':
        return <Zap className="h-4 w-4" />;
      case 'wind':
        return <Globe className="h-4 w-4" />;
      case 'battery':
        return <TrendingUp className="h-4 w-4" />;
      default:
        return <Newspaper className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'solar':
        return 'bg-yellow-500';
      case 'wind':
        return 'bg-blue-500';
      case 'battery':
        return 'bg-green-500';
      case 'policy':
        return 'bg-purple-500';
      case 'technology':
        return 'bg-orange-500';
      default:
        return 'bg-gray-500';
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const now = new Date();
    const published = new Date(dateString);
    const diffInHours = Math.floor((now.getTime() - published.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    return `${Math.floor(diffInHours / 24)}d ago`;
  };

  const handleRequestQuote = () => {
    navigate('/solar-system-design');
    toast({
      title: "Request Quote",
      description: "Redirecting to solar system design for your custom quote",
    });
  };

  const handleSignUp = () => {
    navigate('/register');
    toast({
      title: "Sign Up",
      description: "Join our community for exclusive energy insights",
    });
  };

  const toggleRealTimeSearch = () => {
    setRealTimeSearch(!realTimeSearch);
    toast({
      title: realTimeSearch ? "Real-time Search Disabled" : "Real-time Search Enabled",
      description: realTimeSearch ? "Switched to standard search mode" : "Now searching in real-time",
    });
  };

  return (
    <div className="container px-4 py-8 mx-auto">
      {/* Header with Action Buttons */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Newspaper className="h-8 w-8 text-primary" />
            Energy News
          </h1>
          <p className="text-muted-foreground mt-1">
            Stay updated with the latest developments in renewable energy
          </p>
          <div className="flex items-center gap-2 mt-2">
            <RefreshCw className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">
              Last updated: {lastUpdate.toLocaleTimeString()}
            </span>
            {realTimeSearch && (
              <Badge variant="destructive" className="ml-2">
                LIVE
              </Badge>
            )}
          </div>
        </div>
        
        <div className="flex flex-col gap-4 w-full md:w-auto">
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search energy news..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
            <Button
              size="sm"
              variant={realTimeSearch ? "destructive" : "outline"}
              className="absolute right-2 top-1/2 transform -translate-y-1/2"
              onClick={toggleRealTimeSearch}
            >
              {realTimeSearch ? "LIVE" : "Real-time"}
            </Button>
          </div>
          
          {/* Action Buttons */}
          <div className="flex gap-2">
            <Button onClick={handleRequestQuote} className="flex items-center gap-2">
              <Quote className="h-4 w-4" />
              Request Quote
            </Button>
            <Button onClick={handleSignUp} variant="outline" className="flex items-center gap-2">
              <UserPlus className="h-4 w-4" />
              Sign Up
            </Button>
          </div>
        </div>
      </div>

      {/* Function Sections */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => navigate('/solar-system-design')}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wrench className="h-5 w-5 text-blue-600" />
              Functions & Tools
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Access professional solar design tools, calculators, and system analysis features.
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => navigate('/installer-directory')}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-green-600" />
              Installer Access
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Find certified installers, access professional tools, and manage installation projects.
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => navigate('/community')}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-purple-600" />
              Community
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Join discussions, share experiences, and connect with renewable energy enthusiasts.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Video Section */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <Play className="h-6 w-6 text-red-500" />
          Energy & Technology Solutions
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {videoContent.map((video) => (
            <Card key={video.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="relative aspect-video bg-gray-100 rounded-md overflow-hidden">
                  <iframe
                    src={`https://www.youtube.com/embed/${video.videoId}`}
                    title={video.title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full"
                  />
                </div>
                <CardTitle className="text-lg">{video.title}</CardTitle>
                <Badge variant="outline">{video.category}</Badge>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{video.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Trending Section */}
      {trendingArticles.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-red-500" />
            Trending Now
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {trendingArticles.slice(0, 3).map((article, index) => (
              <motion.div
                key={article.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="hover:shadow-lg transition-shadow border-red-200">
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-2 mb-2">
                      {getCategoryIcon(article.category)}
                      <Badge variant="destructive" className="text-xs">
                        Trending
                      </Badge>
                      <div className={`w-2 h-2 rounded-full ${getCategoryColor(article.category)}`} />
                    </div>
                    <CardTitle className="text-lg line-clamp-2">{article.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground line-clamp-3 mb-3">
                      {article.summary}
                    </p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
                      <span>{article.source}</span>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {formatTimeAgo(article.publishedAt)}
                      </div>
                    </div>
                    {article.originalSource && (
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="flex-1 flex items-center gap-2"
                          onClick={() => window.open(article.url, '_blank')}
                        >
                          <ExternalLink className="h-3 w-3" />
                          Read Article
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="flex items-center gap-2"
                          onClick={() => window.open(article.originalSource, '_blank')}
                        >
                          Original Source
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      <Tabs defaultValue="all" className="space-y-6" onValueChange={setSelectedCategory}>
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="all">All News</TabsTrigger>
          <TabsTrigger value="solar">Solar</TabsTrigger>
          <TabsTrigger value="wind">Wind</TabsTrigger>
          <TabsTrigger value="battery">Battery</TabsTrigger>
          <TabsTrigger value="policy">Policy</TabsTrigger>
          <TabsTrigger value="technology">Technology</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedCategory} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredArticles.map((article, index) => (
              <motion.div
                key={article.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center gap-2 mb-2">
                      {getCategoryIcon(article.category)}
                      <Badge variant="outline" className="text-xs capitalize">
                        {article.category}
                      </Badge>
                      {article.trending && (
                        <Badge variant="destructive" className="text-xs">
                          Trending
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-lg line-clamp-2">{article.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <CardDescription className="line-clamp-3">
                      {article.summary}
                    </CardDescription>
                    
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span className="font-medium">{article.source}</span>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {formatTimeAgo(article.publishedAt)}
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1 flex items-center gap-2"
                        onClick={() => window.open(article.url, '_blank')}
                      >
                        <ExternalLink className="h-3 w-3" />
                        Read Full Article
                      </Button>
                      {article.originalSource && (
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => window.open(article.originalSource, '_blank')}
                          title="View original source"
                        >
                          Source
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {filteredArticles.length === 0 && !loading && (
            <div className="text-center py-12">
              <Newspaper className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No articles found matching your criteria.</p>
              <Button onClick={() => setSearchTerm('')} className="mt-4">
                Clear Search
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EnergyNews;

import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { useFirebaseAuth } from '@/contexts/FirebaseAuthContext';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { 
  Calculator, 
  Zap, 
  Wrench, 
  Truck, 
  Shield, 
  DollarSign,
  Clock,
  Battery,
  Sun,
  Home,
  Settings,
  TrendingUp,
  MapPin,
  CheckCircle,
  Lock,
  Star,
  Eye,
  CreditCard,
  User
} from 'lucide-react';
import SolarCalculator from '@/components/SolarCalculator';

const SolarSystemDesign: React.FC = () => {
  const { user, isAuthenticated } = useFirebaseAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // All state hooks must be called unconditionally
  const [selectedSystem, setSelectedSystem] = useState<'residential' | 'commercial'>('residential');
  const [systemSize, setSystemSize] = useState(6); // kW
  const [selectedPanelType, setSelectedPanelType] = useState('monocrystalline');
  const [selectedInverterType, setSelectedInverterType] = useState('string');
  const [selectedMountType, setSelectedMountType] = useState('roof-pitched');
  const [includeBattery, setIncludeBattery] = useState(false);
  const [batterySize, setBatterySize] = useState(10); // kWh
  const [location, setLocation] = useState('california');
  const [totalCost, setTotalCost] = useState(0);
  const [installationTime, setInstallationTime] = useState(0);
  const [demoMode, setDemoMode] = useState(false);
  const [demoUsageCount, setDemoUsageCount] = useState(0);

  // All useEffect hooks must be called unconditionally
  useEffect(() => {
    // Get demo usage from localStorage
    const storedDemoCount = localStorage.getItem('solar-design-demo-count');
    setDemoUsageCount(storedDemoCount ? parseInt(storedDemoCount) : 0);
  }, []);

  // Calculate costs based on selections - this useEffect must be called unconditionally
  useEffect(() => {
    const panelTypes = [
      {
        id: 'monocrystalline',
        name: 'Monocrystalline',
        efficiency: 22,
        lifespan: 30,
        costPerWatt: 0.80,
        pros: ['Highest efficiency', 'Space efficient', 'Long lifespan', 'Best performance in heat'],
        cons: ['Higher upfront cost', 'Manufacturing intensive']
      },
      {
        id: 'polycrystalline',
        name: 'Polycrystalline',
        efficiency: 17,
        lifespan: 25,
        costPerWatt: 0.65,
        pros: ['Lower cost', 'Good performance', 'Environmentally friendly production'],
        cons: ['Lower efficiency', 'Requires more space', 'Temperature sensitive']
      },
      {
        id: 'thin-film',
        name: 'Thin Film',
        efficiency: 12,
        lifespan: 20,
        costPerWatt: 0.50,
        pros: ['Flexible installation', 'Works in low light', 'Lowest cost', 'Better shade tolerance'],
        cons: ['Lowest efficiency', 'Requires most space', 'Shorter lifespan']
      }
    ];

    const inverterTypes = [
      {
        id: 'string',
        name: 'String Inverters',
        efficiency: 97,
        costPerWatt: 0.25,
        lifespan: 12,
        pros: ['Lower cost', 'Easy maintenance', 'Centralized monitoring', 'Proven technology'],
        cons: ['Single point failure', 'Shading affects all panels', 'Less optimization']
      },
      {
        id: 'power-optimizers',
        name: 'Power Optimizers',
        efficiency: 98,
        costPerWatt: 0.35,
        lifespan: 25,
        pros: ['Panel-level optimization', 'Better shading tolerance', 'Module monitoring'],
        cons: ['Higher cost', 'More roof components', 'Complex installation']
      },
      {
        id: 'microinverters',
        name: 'Microinverters',
        efficiency: 96,
        costPerWatt: 0.45,
        lifespan: 25,
        pros: ['Maximum flexibility', 'No single point failure', 'Best monitoring', 'Easy expansion'],
        cons: ['Highest cost', 'Roof-level maintenance', 'More failure points']
      }
    ];

    const mountingTypes = [
      {
        id: 'roof-pitched',
        name: 'Pitched Roof Mount',
        costPerWatt: 0.30,
        installDays: 1,
        description: 'Standard mounting for sloped roofs'
      },
      {
        id: 'roof-flat',
        name: 'Flat Roof Mount',
        costPerWatt: 0.40,
        installDays: 1.5,
        description: 'Ballasted or penetrating mounts for flat roofs'
      },
      {
        id: 'ground-mount',
        name: 'Ground Mount',
        costPerWatt: 0.60,
        installDays: 2,
        description: 'Foundation-based ground mounting system'
      },
      {
        id: 'tracking',
        name: 'Solar Tracking',
        costPerWatt: 1.20,
        installDays: 3,
        description: 'Single or dual-axis tracking system'
      }
    ];

    const locationFactors = {
      california: { laborCost: 1.2, permitCost: 1.1, incentive: 0.30, name: 'California' },
      texas: { laborCost: 0.9, permitCost: 0.8, incentive: 0.26, name: 'Texas' },
      florida: { laborCost: 0.85, permitCost: 0.75, incentive: 0.26, name: 'Florida' },
      newyork: { laborCost: 1.3, permitCost: 1.2, incentive: 0.25, name: 'New York' },
      arizona: { laborCost: 0.95, permitCost: 0.9, incentive: 0.25, name: 'Arizona' }
    };

    const selectedPanel = panelTypes.find(p => p.id === selectedPanelType);
    const selectedInverter = inverterTypes.find(i => i.id === selectedInverterType);
    const selectedMount = mountingTypes.find(m => m.id === selectedMountType);
    const locationData = locationFactors[location as keyof typeof locationFactors];

    if (selectedPanel && selectedInverter && selectedMount && locationData) {
      const systemWatts = systemSize * 1000;
      
      // Equipment costs
      const panelCost = systemWatts * selectedPanel.costPerWatt;
      const inverterCost = systemWatts * selectedInverter.costPerWatt;
      const mountingCost = systemWatts * selectedMount.costPerWatt;
      const electricalCost = systemWatts * 0.25; // $0.25/W for electrical components
      const batteryCost = includeBattery ? batterySize * 800 : 0; // $800/kWh

      // Labor and soft costs
      const laborCost = (systemWatts * 0.50) * locationData.laborCost;
      const permitCost = (500 + systemSize * 50) * locationData.permitCost;
      const designCost = 800;
      const overheadCost = (panelCost + inverterCost + mountingCost + electricalCost + laborCost) * 0.15;

      const subtotal = panelCost + inverterCost + mountingCost + electricalCost + batteryCost + laborCost + permitCost + designCost + overheadCost;
      
      setTotalCost(subtotal);
      
      // Calculate installation time
      const baseTime = selectedMount.installDays + (includeBattery ? 0.5 : 0);
      const sizeMultiplier = systemSize > 10 ? 1.5 : systemSize > 6 ? 1.2 : 1;
      setInstallationTime(baseTime * sizeMultiplier);
    }
  }, [selectedPanelType, selectedInverterType, selectedMountType, systemSize, includeBattery, batterySize, location]);

  // Memoize user access to prevent unnecessary re-renders
  const hasAccess = useMemo(() => {
    if (isAuthenticated && user) {
      return user.subscriptionTier && ['basic', 'professional', 'enterprise'].includes(user.subscriptionTier);
    }
    return false;
  }, [isAuthenticated, user]);

  // Demo mode limitations
  const DEMO_LIMIT = 3;
  const canUseDemo = demoUsageCount < DEMO_LIMIT;

  const handleDemoAccess = () => {
    if (!canUseDemo) {
      toast({
        title: "Demo Limit Reached",
        description: "You've used all your free demos. Please upgrade to continue.",
        variant: "destructive"
      });
      return;
    }

    const newCount = demoUsageCount + 1;
    setDemoUsageCount(newCount);
    localStorage.setItem('solar-design-demo-count', newCount.toString());
    setDemoMode(true);
    
    toast({
      title: "Demo Mode Activated",
      description: `Demo ${newCount}/${DEMO_LIMIT} - Limited features available.`,
    });
  };

  const handleUpgrade = () => {
    if (!isAuthenticated) {
      navigate('/register');
    } else {
      navigate('/pricing');
    }
  };

  // Helper functions that can be called conditionally
  const getCostBreakdown = () => {
    const selectedPanel = panelTypes.find(p => p.id === selectedPanelType);
    const selectedInverter = inverterTypes.find(i => i.id === selectedInverterType);
    const selectedMount = mountingTypes.find(m => m.id === selectedMountType);
    const locationData = locationFactors[location as keyof typeof locationFactors];

    if (!selectedPanel || !selectedInverter || !selectedMount || !locationData) return [];

    const systemWatts = systemSize * 1000;
    
    const panelCost = systemWatts * selectedPanel.costPerWatt;
    const inverterCost = systemWatts * selectedInverter.costPerWatt;
    const mountingCost = systemWatts * selectedMount.costPerWatt;
    const electricalCost = systemWatts * 0.25;
    const batteryCost = includeBattery ? batterySize * 800 : 0;
    const laborCost = (systemWatts * 0.50) * locationData.laborCost;
    const permitCost = (500 + systemSize * 50) * locationData.permitCost;
    const designCost = 800;
    const overheadCost = (panelCost + inverterCost + mountingCost + electricalCost + laborCost) * 0.15;

    return [
      { name: 'Solar Panels', cost: panelCost, percentage: (panelCost / totalCost) * 100 },
      { name: 'Inverters', cost: inverterCost, percentage: (inverterCost / totalCost) * 100 },
      { name: 'Mounting System', cost: mountingCost, percentage: (mountingCost / totalCost) * 100 },
      { name: 'Electrical Components', cost: electricalCost, percentage: (electricalCost / totalCost) * 100 },
      ...(includeBattery ? [{ name: 'Battery Storage', cost: batteryCost, percentage: (batteryCost / totalCost) * 100 }] : []),
      { name: 'Labor & Installation', cost: laborCost, percentage: (laborCost / totalCost) * 100 },
      { name: 'Permits & Design', cost: permitCost + designCost, percentage: ((permitCost + designCost) / totalCost) * 100 },
      { name: 'Overhead & Profit', cost: overheadCost, percentage: (overheadCost / totalCost) * 100 }
    ];
  };

  const panelTypes = [
    {
      id: 'monocrystalline',
      name: 'Monocrystalline',
      efficiency: 22,
      lifespan: 30,
      costPerWatt: 0.80,
      pros: ['Highest efficiency', 'Space efficient', 'Long lifespan', 'Best performance in heat'],
      cons: ['Higher upfront cost', 'Manufacturing intensive']
    },
    {
      id: 'polycrystalline',
      name: 'Polycrystalline',
      efficiency: 17,
      lifespan: 25,
      costPerWatt: 0.65,
      pros: ['Lower cost', 'Good performance', 'Environmentally friendly production'],
      cons: ['Lower efficiency', 'Requires more space', 'Temperature sensitive']
    },
    {
      id: 'thin-film',
      name: 'Thin Film',
      efficiency: 12,
      lifespan: 20,
      costPerWatt: 0.50,
      pros: ['Flexible installation', 'Works in low light', 'Lowest cost', 'Better shade tolerance'],
      cons: ['Lowest efficiency', 'Requires most space', 'Shorter lifespan']
    }
  ];

  const inverterTypes = [
    {
      id: 'string',
      name: 'String Inverters',
      efficiency: 97,
      costPerWatt: 0.25,
      lifespan: 12,
      pros: ['Lower cost', 'Easy maintenance', 'Centralized monitoring', 'Proven technology'],
      cons: ['Single point failure', 'Shading affects all panels', 'Less optimization']
    },
    {
      id: 'power-optimizers',
      name: 'Power Optimizers',
      efficiency: 98,
      costPerWatt: 0.35,
      lifespan: 25,
      pros: ['Panel-level optimization', 'Better shading tolerance', 'Module monitoring'],
      cons: ['Higher cost', 'More roof components', 'Complex installation']
    },
    {
      id: 'microinverters',
      name: 'Microinverters',
      efficiency: 96,
      costPerWatt: 0.45,
      lifespan: 25,
      pros: ['Maximum flexibility', 'No single point failure', 'Best monitoring', 'Easy expansion'],
      cons: ['Highest cost', 'Roof-level maintenance', 'More failure points']
    }
  ];

  const mountingTypes = [
    {
      id: 'roof-pitched',
      name: 'Pitched Roof Mount',
      costPerWatt: 0.30,
      installDays: 1,
      description: 'Standard mounting for sloped roofs'
    },
    {
      id: 'roof-flat',
      name: 'Flat Roof Mount',
      costPerWatt: 0.40,
      installDays: 1.5,
      description: 'Ballasted or penetrating mounts for flat roofs'
    },
    {
      id: 'ground-mount',
      name: 'Ground Mount',
      costPerWatt: 0.60,
      installDays: 2,
      description: 'Foundation-based ground mounting system'
    },
    {
      id: 'tracking',
      name: 'Solar Tracking',
      costPerWatt: 1.20,
      installDays: 3,
      description: 'Single or dual-axis tracking system'
    }
  ];

  const locationFactors = {
    california: { laborCost: 1.2, permitCost: 1.1, incentive: 0.30, name: 'California' },
    texas: { laborCost: 0.9, permitCost: 0.8, incentive: 0.26, name: 'Texas' },
    florida: { laborCost: 0.85, permitCost: 0.75, incentive: 0.26, name: 'Florida' },
    newyork: { laborCost: 1.3, permitCost: 1.2, incentive: 0.25, name: 'New York' },
    arizona: { laborCost: 0.95, permitCost: 0.9, incentive: 0.25, name: 'Arizona' }
  };

  const installationSteps = [
    { 
      step: 1, 
      title: 'Site Assessment', 
      duration: '2-4 hours', 
      description: 'Comprehensive roof inspection, electrical evaluation, shading analysis, and structural assessment',
      cost: 200,
      dependencies: []
    },
    { 
      step: 2, 
      title: 'Engineering & Permits', 
      duration: '2-4 weeks', 
      description: 'Custom system design, engineering stamps, permit applications, utility interconnection agreements',
      cost: 800,
      dependencies: [1]
    },
    { 
      step: 3, 
      title: 'Equipment Procurement', 
      duration: '1-3 weeks', 
      description: 'Solar panels, inverters, mounting hardware, electrical components delivery and staging',
      cost: 0,
      dependencies: [2]
    },
    { 
      step: 4, 
      title: 'Installation Day 1', 
      duration: '6-8 hours', 
      description: 'Mounting system installation, roof attachments, grounding, and safety setup',
      cost: 1200,
      dependencies: [3]
    },
    { 
      step: 5, 
      title: 'Installation Day 2', 
      duration: '6-8 hours', 
      description: 'Panel mounting, DC wiring, inverter installation, and system commissioning',
      cost: 1000,
      dependencies: [4]
    },
    { 
      step: 6, 
      title: 'Electrical & Inspection', 
      duration: '1-2 weeks', 
      description: 'AC electrical connections, utility meter upgrade, city inspection scheduling',
      cost: 600,
      dependencies: [5]
    },
    { 
      step: 7, 
      title: 'System Activation', 
      duration: '1-3 days', 
      description: 'Utility approval, net metering setup, monitoring activation, customer training',
      cost: 300,
      dependencies: [6]
    }
  ];

  // Access Control Component - moved to after all hooks
  const AccessControl = () => (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="relative">
              <Calculator className="h-16 w-16 text-primary" />
              <Lock className="h-6 w-6 absolute -top-1 -right-1 bg-background border rounded-full p-1" />
            </div>
          </div>
          <CardTitle className="text-2xl">Professional Solar Design Tool</CardTitle>
          <p className="text-muted-foreground mt-2">
            Advanced solar system design with comprehensive materials and installation analysis
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Demo Section */}
          <div className="border rounded-lg p-6 bg-blue-50">
            <div className="flex items-center gap-3 mb-4">
              <Eye className="h-5 w-5 text-blue-600" />
              <h3 className="font-semibold text-blue-900">Try Demo Version</h3>
              <Badge variant="outline" className="text-blue-600 border-blue-300">
                {demoUsageCount}/{DEMO_LIMIT} used
              </Badge>
            </div>
            <p className="text-sm text-blue-700 mb-4">
              Test our professional design tool with limited features. Perfect for exploring the interface and basic calculations.
            </p>
            <Button 
              onClick={handleDemoAccess}
              disabled={!canUseDemo}
              className="w-full"
              variant={canUseDemo ? "default" : "secondary"}
            >
              {canUseDemo ? (
                <>
                  <Eye className="h-4 w-4 mr-2" />
                  Start Demo ({DEMO_LIMIT - demoUsageCount} remaining)
                </>
              ) : (
                <>
                  <Lock className="h-4 w-4 mr-2" />
                  Demo Limit Reached
                </>
              )}
            </Button>
          </div>

          {/* Premium Features */}
          <div className="space-y-4">
            <h3 className="font-semibold flex items-center gap-2">
              <Star className="h-5 w-5 text-solar-yellow fill-solar-yellow" />
              Full Version Features
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Complete materials calculator</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Installation timeline planner</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Detailed cost breakdown</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Professional PDF reports</span>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Multiple panel comparisons</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Battery storage integration</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>ROI & financing analysis</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Save unlimited projects</span>
                </div>
              </div>
            </div>
          </div>

          {/* Pricing */}
          <div className="border rounded-lg p-4 bg-gradient-to-r from-primary/5 to-primary/10">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-semibold">Professional Access</h4>
                <p className="text-sm text-muted-foreground">Starting at $29.99/month</p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-primary">$29.99</div>
                <div className="text-xs text-muted-foreground">per month</div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button onClick={handleUpgrade} className="flex-1">
              {isAuthenticated ? (
                <>
                  <CreditCard className="h-4 w-4 mr-2" />
                  Upgrade Plan
                </>
              ) : (
                <>
                  <User className="h-4 w-4 mr-2" />
                  Sign Up & Subscribe
                </>
              )}
            </Button>
            <Button variant="outline" onClick={() => navigate('/')}>
              <Calculator className="h-4 w-4 mr-2" />
              Free Calculator
            </Button>
          </div>

          <div className="text-center text-xs text-muted-foreground">
            <p>✅ 30-day money-back guarantee</p>
            <p>🔒 Secure payment processing</p>
            <p>📞 Professional customer support</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // Conditional rendering logic - placed after all hooks
  if (!hasAccess && !demoMode) {
    return <AccessControl />;
  }

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Demo Mode Banner */}
      {demoMode && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-blue-600" />
              <span className="font-medium text-blue-900">Demo Mode Active</span>
              <Badge variant="outline" className="text-blue-600 border-blue-300">
                Limited Features
              </Badge>
            </div>
            <Button size="sm" onClick={handleUpgrade}>
              Upgrade for Full Access
            </Button>
          </div>
        </div>
      )}

      <div className="text-center">
        <h1 className="text-3xl font-bold mb-2">
          Solar System Design & Calculator
          {demoMode && <span className="text-blue-600"> (Demo)</span>}
        </h1>
        <p className="text-muted-foreground text-lg">
          {demoMode 
            ? "Limited demo version - upgrade for full professional features"
            : "Comprehensive solar panel system design with materials and installation details"
          }
        </p>
      </div>

      <Tabs defaultValue="calculator" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="calculator">Calculator</TabsTrigger>
          <TabsTrigger value="materials" disabled={demoMode}>
            Materials {demoMode && <Lock className="h-3 w-3 ml-1" />}
          </TabsTrigger>
          <TabsTrigger value="installation" disabled={demoMode}>
            Installation {demoMode && <Lock className="h-3 w-3 ml-1" />}
          </TabsTrigger>
          <TabsTrigger value="costs" disabled={demoMode}>
            Cost Breakdown {demoMode && <Lock className="h-3 w-3 ml-1" />}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="calculator" className="space-y-6">
          <SolarCalculator premiumMode={!demoMode} />
          
          {demoMode && (
            <Card className="border-dashed border-2 border-blue-300 bg-blue-50">
              <CardContent className="p-6 text-center">
                <Lock className="h-8 w-8 mx-auto mb-4 text-blue-600" />
                <h3 className="font-semibold text-blue-900 mb-2">Demo Limitations</h3>
                <p className="text-blue-700 text-sm mb-4">
                  Demo mode provides basic calculations only. Upgrade for advanced features, detailed analysis, and professional reports.
                </p>
                <Button onClick={handleUpgrade}>
                  <Star className="h-4 w-4 mr-2" />
                  Upgrade Now
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="materials" className="space-y-6">
          <div className="text-center py-12">
            <Lock className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">Professional Feature</h3>
            <p className="text-muted-foreground mb-4">
              Materials selection and comparison requires a professional subscription.
            </p>
            <Button onClick={handleUpgrade}>
              Upgrade to Access Materials
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="installation" className="space-y-6">
          <div className="text-center py-12">
            <Lock className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">Professional Feature</h3>
            <p className="text-muted-foreground mb-4">
              Installation timeline and process details require a professional subscription.
            </p>
            <Button onClick={handleUpgrade}>
              Upgrade to Access Installation Details
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="costs" className="space-y-6">
          <div className="text-center py-12">
            <Lock className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">Professional Feature</h3>
            <p className="text-muted-foreground mb-4">
              Detailed cost breakdown and financial analysis require a professional subscription.
            </p>
            <Button onClick={handleUpgrade}>
              Upgrade to Access Cost Analysis
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SolarSystemDesign;

import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calculator, Bookmark, Users, DollarSign, Sun, Package, Wrench, Calendar, CheckCircle, Globe, Laptop, MessageSquare } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  return (
    <div className="container px-4 py-8 mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Welcome, {user?.name || 'User'}!</h1>
        <p className="text-muted-foreground mt-2">
          Your Sunalyzer Dashboard - {user?.subscriptionTier || 'Free'} Plan
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="col-span-3">
          <CardHeader className="pb-3">
            <CardTitle>Your Solar Summary</CardTitle>
            <CardDescription>Overview of your solar energy profile</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-muted/50 p-4 rounded-lg">
                <h3 className="font-medium mb-1">Saved Calculations</h3>
                <p className="text-2xl font-bold">0</p>
                <p className="text-sm text-muted-foreground mt-1">No calculations saved yet</p>
              </div>
              <div className="bg-muted/50 p-4 rounded-lg">
                <h3 className="font-medium mb-1">Potential Savings</h3>
                <p className="text-2xl font-bold">$0</p>
                <p className="text-sm text-muted-foreground mt-1">Calculate to see potential savings</p>
              </div>
              <div className="bg-muted/50 p-4 rounded-lg">
                <h3 className="font-medium mb-1">Plan Status</h3>
                <p className="text-2xl font-bold capitalize">{user?.subscriptionTier || 'Free'}</p>
                <p className="text-sm text-muted-foreground mt-1">
                  {user?.subscriptionTier === 'free' ? 'Upgrade for more features' : 'All features unlocked!'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Service Plans Section */}
        <Card className="col-span-3 border-primary/20 shadow">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Wrench className="h-5 w-5 text-primary" />
              Solar Services & Maintenance
            </CardTitle>
            <CardDescription>
              Protect your solar investment with our professional service plans
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="plans" className="mb-6">
              <TabsList className="w-full max-w-md grid grid-cols-3">
                <TabsTrigger value="plans">
                  <Package className="h-4 w-4 mr-2" />
                  Service Plans
                </TabsTrigger>
                <TabsTrigger value="remote">
                  <Globe className="h-4 w-4 mr-2" />
                  Remote Services
                </TabsTrigger>
                <TabsTrigger value="schedule">
                  <Calendar className="h-4 w-4 mr-2" />
                  Schedule Service
                </TabsTrigger>
              </TabsList>
              <TabsContent value="plans" className="pt-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-muted/20 p-4 rounded-lg border border-primary/10 flex flex-col">
                    <h3 className="font-medium mb-1">Basic Maintenance</h3>
                    <p className="text-xl font-bold">$149<span className="text-sm font-normal text-muted-foreground">/year</span></p>
                    <ul className="text-sm space-y-1 mb-4 mt-2 flex-grow">
                      <li className="flex items-start gap-1">
                        <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5" />
                        <span>Annual system inspection</span>
                      </li>
                      <li className="flex items-start gap-1">
                        <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5" />
                        <span>Panel cleaning</span>
                      </li>
                    </ul>
                    <Link to="/service-plans/basic">
                      <Button variant="outline" className="w-full">View Details</Button>
                    </Link>
                  </div>
                  <div className="bg-primary/5 p-4 rounded-lg border-2 border-primary/20 flex flex-col relative">
                    <div className="absolute -top-3 right-3 bg-primary text-white text-xs px-2 py-0.5 rounded-full">Popular</div>
                    <h3 className="font-medium mb-1">Standard Care</h3>
                    <p className="text-xl font-bold">$249<span className="text-sm font-normal text-muted-foreground">/year</span></p>
                    <ul className="text-sm space-y-1 mb-4 mt-2 flex-grow">
                      <li className="flex items-start gap-1">
                        <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5" />
                        <span>Bi-annual inspection</span>
                      </li>
                      <li className="flex items-start gap-1">
                        <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5" />
                        <span>Inverter maintenance</span>
                      </li>
                    </ul>
                    <Link to="/service-plans">
                      <Button className="w-full">Select Plan</Button>
                    </Link>
                  </div>
                  <div className="bg-muted/20 p-4 rounded-lg border border-primary/10 flex flex-col">
                    <h3 className="font-medium mb-1">Premium Protection</h3>
                    <p className="text-xl font-bold">$499<span className="text-sm font-normal text-muted-foreground">/year</span></p>
                    <ul className="text-sm space-y-1 mb-4 mt-2 flex-grow">
                      <li className="flex items-start gap-1">
                        <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5" />
                        <span>Quarterly inspection</span>
                      </li>
                      <li className="flex items-start gap-1">
                        <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5" />
                        <span>Priority service</span>
                      </li>
                    </ul>
                    <Link to="/service-plans">
                      <Button variant="outline" className="w-full">View Details</Button>
                    </Link>
                  </div>
                </div>
                <div className="flex justify-center mt-4">
                  <Link to="/service-plans">
                    <Button variant="link" className="text-primary">Compare All Plans →</Button>
                  </Link>
                </div>
              </TabsContent>
              <TabsContent value="remote" className="pt-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-muted/20 p-4 rounded-lg border border-primary/10 flex flex-col">
                    <h3 className="font-medium mb-1">Remote Diagnostics</h3>
                    <p className="text-xl font-bold">$79<span className="text-sm font-normal text-muted-foreground">/session</span></p>
                    <ul className="text-sm space-y-1 mb-4 mt-2 flex-grow">
                      <li className="flex items-start gap-1">
                        <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5" />
                        <span>System performance analysis</span>
                      </li>
                      <li className="flex items-start gap-1">
                        <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5" />
                        <span>Online troubleshooting</span>
                      </li>
                    </ul>
                    <Link to="/service-plans">
                      <Button variant="outline" className="w-full">Book Session</Button>
                    </Link>
                  </div>
                  <div className="bg-primary/5 p-4 rounded-lg border-2 border-primary/20 flex flex-col relative">
                    <div className="absolute -top-3 right-3 bg-primary text-white text-xs px-2 py-0.5 rounded-full">Popular</div>
                    <h3 className="font-medium mb-1">Virtual Consultation</h3>
                    <p className="text-xl font-bold">$49<span className="text-sm font-normal text-muted-foreground">/month</span></p>
                    <ul className="text-sm space-y-1 mb-4 mt-2 flex-grow">
                      <li className="flex items-start gap-1">
                        <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5" />
                        <span>Unlimited chat support</span>
                      </li>
                      <li className="flex items-start gap-1">
                        <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5" />
                        <span>Monthly video check-ins</span>
                      </li>
                      <li className="flex items-start gap-1">
                        <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5" />
                        <span>Performance reports</span>
                      </li>
                    </ul>
                    <Link to="/service-plans">
                      <Button className="w-full">Subscribe Now</Button>
                    </Link>
                  </div>
                  <div className="bg-muted/20 p-4 rounded-lg border border-primary/10 flex flex-col">
                    <h3 className="font-medium mb-1">Tech Support</h3>
                    <p className="text-xl font-bold">$29<span className="text-sm font-normal text-muted-foreground">/month</span></p>
                    <ul className="text-sm space-y-1 mb-4 mt-2 flex-grow">
                      <li className="flex items-start gap-1">
                        <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5" />
                        <span>Chat support (business hours)</span>
                      </li>
                      <li className="flex items-start gap-1">
                        <CheckCircle className="h-3.5 w-3.5 text-green-500 mt-0.5" />
                        <span>App troubleshooting</span>
                      </li>
                    </ul>
                    <Link to="/service-plans">
                      <Button variant="outline" className="w-full">Get Support</Button>
                    </Link>
                  </div>
                </div>
                <div className="flex justify-center mt-6">
                  <div className="bg-muted/30 p-4 rounded-lg max-w-2xl text-center">
                    <h4 className="font-medium mb-2 flex items-center justify-center gap-2">
                      <MessageSquare className="h-4 w-4 text-primary" />
                      Available Support Channels
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
                      <div className="bg-background rounded p-2 flex items-center justify-center gap-1">
                        <MessageSquare className="h-3.5 w-3.5 text-primary" />
                        <span>Live Chat Support</span>
                      </div>
                      <div className="bg-background rounded p-2 flex items-center justify-center gap-1">
                        <Laptop className="h-3.5 w-3.5 text-primary" />
                        <span>Video Consultation</span>
                      </div>
                      <div className="bg-background rounded p-2 flex items-center justify-center gap-1">
                        <Globe className="h-3.5 w-3.5 text-primary" />
                        <span>Remote Monitoring</span>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="schedule" className="pt-4">
                <div className="max-w-md mx-auto text-center space-y-4">
                  <p>Need maintenance or have an issue with your solar system?</p>
                  <Link to="/service-plans" className="block">
                    <Button>Schedule Service Visit</Button>
                  </Link>
                  <p className="text-sm text-muted-foreground">Current response time: 24-48 hours</p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              Solar Calculator
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-muted-foreground">
              Calculate your solar energy needs and potential savings based on your location.
            </p>
            <Link to="/">
              <Button>New Calculation</Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bookmark className="h-5 w-5" />
              Saved Calculations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-muted-foreground">
              Access your saved solar calculations and reports.
            </p>
            <Link to="/saved-calculations">
              <Button>View Saved</Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Find Installers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-muted-foreground">
              Connect with verified solar installation professionals in your area.
            </p>
            <Link to="/installers">
              <Button>Find Installers</Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              Remote Support
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-muted-foreground">
              Get expert help with your solar system without an on-site visit.
            </p>
            <Link to="/service-plans">
              <Button>Connect With Expert</Button>
            </Link>
          </CardContent>
        </Card>

        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Subscription Plan
              </CardTitle>
              <CardDescription>
                {user?.subscriptionTier === 'free' 
                  ? 'Upgrade to access advanced features and professional tools'
                  : `You're currently on the ${user?.subscriptionTier} plan`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <div>
                  <h3 className="font-medium text-lg capitalize">{user?.subscriptionTier || 'Free'} Plan</h3>
                  <p className="text-muted-foreground">
                    {user?.subscriptionTier === 'free' 
                      ? 'Limited access to basic features'
                      : 'Full access to all features'}
                  </p>
                </div>
                <div className="ml-auto">
                  <Link to="/pricing">
                    <Button variant="outline">
                      {user?.subscriptionTier === 'free' ? 'Upgrade Plan' : 'Manage Plan'}
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;


import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Index from '@/pages/Index';
import About from '@/pages/About';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import Blog from '@/pages/Blog';
import BlogPost from '@/pages/BlogPost';
import Community from '@/pages/Community';
import PricingPage from '@/pages/PricingPage';
import SaasPlans from '@/pages/SaasPlans';
import Terms from '@/pages/Terms';
import Privacy from '@/pages/Privacy';
import JobsMarketplace from '@/pages/JobsMarketplace';
import NotFound from '@/pages/NotFound';
import Dashboard from '@/pages/Dashboard';
import Profile from '@/pages/Profile';
import SubscriptionDashboard from '@/pages/SubscriptionDashboard';
import SavedCalculations from '@/pages/SavedCalculations';
import PremiumCalculator from '@/pages/PremiumCalculator';
import InstallerDirectory from '@/pages/InstallerDirectory';
import InstallerRegistration from '@/pages/InstallerRegistration';
import InstallerWelcome from '@/pages/InstallerWelcome';
import ServicePlans from '@/pages/ServicePlans';
import BasicMaintenancePlan from '@/pages/BasicMaintenancePlan';
import SolarSystemDesign from '@/pages/SolarSystemDesign';
import Admin from '@/pages/Admin';
import EnergyNews from '@/pages/EnergyNews';
import Layout from '@/components/Layout';
import { FirebaseAuthProvider } from '@/contexts/FirebaseAuthContext';
import ProtectedRoute from '@/components/ProtectedRoute';

const queryClient = new QueryClient();

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <QueryClientProvider client={queryClient}>
        <FirebaseAuthProvider>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<Index />} />
              <Route path="about" element={<About />} />
              <Route path="login" element={<Login />} />
              <Route path="register" element={<Register />} />
              <Route path="blog" element={<Blog />} />
              <Route path="blog/:slug" element={<BlogPost />} />
              <Route path="community" element={<Community />} />
              <Route path="pricing" element={<PricingPage />} />
              <Route path="saas-plans" element={<SaasPlans />} />
              <Route path="terms" element={<Terms />} />
              <Route path="privacy" element={<Privacy />} />
              <Route path="jobs" element={<JobsMarketplace />} />
              <Route path="solar-design" element={<SolarSystemDesign />} />
              <Route path="installer-directory" element={<InstallerDirectory />} />
              <Route path="installer-registration" element={<InstallerRegistration />} />
              <Route path="service-plans" element={<ServicePlans />} />
              <Route path="energy-news" element={<EnergyNews />} />
              
              {/* Protected Routes */}
              <Route path="dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
              <Route path="profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
              <Route path="subscription" element={<ProtectedRoute><SubscriptionDashboard /></ProtectedRoute>} />
              <Route path="saved-calculations" element={<ProtectedRoute><SavedCalculations /></ProtectedRoute>} />
              <Route path="premium-calculator" element={<ProtectedRoute><PremiumCalculator /></ProtectedRoute>} />
              <Route path="installer-welcome" element={<ProtectedRoute><InstallerWelcome /></ProtectedRoute>} />
              <Route path="basic-maintenance-plan" element={<ProtectedRoute><BasicMaintenancePlan /></ProtectedRoute>} />
              <Route path="admin" element={<ProtectedRoute><Admin /></ProtectedRoute>} />
              
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </FirebaseAuthProvider>
      </QueryClientProvider>
    </BrowserRouter>
  );
};

export default App;

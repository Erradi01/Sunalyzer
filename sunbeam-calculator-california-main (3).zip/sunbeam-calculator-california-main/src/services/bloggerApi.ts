
const BLOGGER_API_KEY = 'YOUR_BLOGGER_API_KEY'; // Replace with actual API key
const BLOG_ID = 'YOUR_BLOG_ID'; // Replace with your Blogger blog ID

export interface BlogPost {
  id: string;
  title: string;
  content: string;
  published: string;
  updated: string;
  url: string;
  author: {
    id: string;
    displayName: string;
    url: string;
    image: {
      url: string;
    };
  };
  replies: {
    totalItems: string;
  };
  labels?: string[];
}

export interface BlogPostsResponse {
  kind: string;
  nextPageToken?: string;
  items: BlogPost[];
}

class BloggerApiService {
  private baseUrl = 'https://www.googleapis.com/blogger/v3';

  async getPosts(maxResults: number = 10, pageToken?: string): Promise<BlogPostsResponse> {
    try {
      const url = new URL(`${this.baseUrl}/blogs/${BLOG_ID}/posts`);
      url.searchParams.append('key', BLOGGER_API_KEY);
      url.searchParams.append('maxResults', maxResults.toString());
      if (pageToken) {
        url.searchParams.append('pageToken', pageToken);
      }

      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error fetching blog posts:', error);
      // Return mock data as fallback
      return this.getMockPosts();
    }
  }

  async getPost(postId: string): Promise<BlogPost> {
    try {
      const url = new URL(`${this.baseUrl}/blogs/${BLOG_ID}/posts/${postId}`);
      url.searchParams.append('key', BLOGGER_API_KEY);

      const response = await fetch(url.toString());
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error fetching blog post:', error);
      // Return mock data as fallback
      return this.getMockPost(postId);
    }
  }

  private getMockPosts(): BlogPostsResponse {
    return {
      kind: "blogger#postList",
      items: [
        {
          id: "1",
          title: "The Economics of Solar Energy in 2025",
          content: "With falling prices and increasing efficiencies, solar energy has become more economically viable than ever before...",
          published: "2025-05-01T10:00:00Z",
          updated: "2025-05-01T10:00:00Z",
          url: "https://sunalyzer.blogspot.com/2025/05/economics-solar-energy.html",
          author: {
            id: "author1",
            displayName: "Sarah Johnson",
            url: "https://blogger.com/profile/author1",
            image: {
              url: "https://images.unsplash.com/photo-1494790108755-2616b612b2fd?w=150&h=150&fit=crop&crop=face"
            }
          },
          replies: {
            totalItems: "5"
          },
          labels: ["Solar Economics", "ROI", "Investment"]
        },
        {
          id: "2",
          title: "Battery Storage: Is It Worth the Cost?",
          content: "Battery prices continue to fall while capacities increase. Let's analyze when battery storage makes financial sense...",
          published: "2025-04-28T14:30:00Z",
          updated: "2025-04-28T14:30:00Z",
          url: "https://sunalyzer.blogspot.com/2025/04/battery-storage-worth-cost.html",
          author: {
            id: "author2",
            displayName: "Mike Chen",
            url: "https://blogger.com/profile/author2",
            image: {
              url: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
            }
          },
          replies: {
            totalItems: "12"
          },
          labels: ["Battery Storage", "Technology", "Cost Analysis"]
        }
      ]
    };
  }

  private getMockPost(id: string): BlogPost {
    const posts = this.getMockPosts().items;
    return posts.find(post => post.id === id) || posts[0];
  }
}

export const bloggerApi = new BloggerApiService();

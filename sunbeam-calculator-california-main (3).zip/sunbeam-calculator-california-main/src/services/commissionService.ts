
import { doc, addDoc, collection, query, where, getDocs, updateDoc } from 'firebase/firestore';
import { db } from '@/config/firebase';

export interface Commission {
  id?: string;
  clientId: string;
  installerId: string;
  projectId: string;
  amount: number;
  commissionRate: number;
  commissionAmount: number;
  status: 'pending' | 'completed' | 'paid';
  createdAt: string;
  paidAt?: string;
}

export interface Project {
  id?: string;
  clientId: string;
  installerId?: string;
  title: string;
  description: string;
  estimatedCost: number;
  status: 'open' | 'assigned' | 'in_progress' | 'completed' | 'cancelled';
  location: string;
  systemSize: number; // in kW
  createdAt: string;
  completedAt?: string;
}

class CommissionService {
  async createProject(project: Omit<Project, 'id' | 'createdAt'>): Promise<string> {
    const projectData = {
      ...project,
      createdAt: new Date().toISOString(),
      status: 'open' as const
    };

    const docRef = await addDoc(collection(db, 'projects'), projectData);
    return docRef.id;
  }

  async assignInstaller(projectId: string, installerId: string): Promise<void> {
    await updateDoc(doc(db, 'projects', projectId), {
      installerId,
      status: 'assigned'
    });
  }

  async completeProject(projectId: string): Promise<void> {
    const projectDoc = await getDocs(query(
      collection(db, 'projects'),
      where('__name__', '==', projectId)
    ));

    if (!projectDoc.empty) {
      const project = projectDoc.docs[0].data() as Project;
      
      // Update project status
      await updateDoc(doc(db, 'projects', projectId), {
        status: 'completed',
        completedAt: new Date().toISOString()
      });

      // Create commission record
      if (project.installerId) {
        const commissionRate = 10; // Default 10% commission
        const commissionAmount = project.estimatedCost * (commissionRate / 100);

        await addDoc(collection(db, 'commissions'), {
          clientId: project.clientId,
          installerId: project.installerId,
          projectId,
          amount: project.estimatedCost,
          commissionRate,
          commissionAmount,
          status: 'pending',
          createdAt: new Date().toISOString()
        });
      }
    }
  }

  async getInstallerCommissions(installerId: string): Promise<Commission[]> {
    const commissionsQuery = query(
      collection(db, 'commissions'),
      where('installerId', '==', installerId)
    );

    const snapshot = await getDocs(commissionsQuery);
    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Commission[];
  }

  async getClientProjects(clientId: string): Promise<Project[]> {
    const projectsQuery = query(
      collection(db, 'projects'),
      where('clientId', '==', clientId)
    );

    const snapshot = await getDocs(projectsQuery);
    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Project[];
  }

  async getAvailableProjects(): Promise<Project[]> {
    const projectsQuery = query(
      collection(db, 'projects'),
      where('status', '==', 'open')
    );

    const snapshot = await getDocs(projectsQuery);
    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Project[];
  }

  async payCommission(commissionId: string): Promise<void> {
    await updateDoc(doc(db, 'commissions', commissionId), {
      status: 'paid',
      paidAt: new Date().toISOString()
    });
  }
}

export const commissionService = new CommissionService();


// Location interface for unified handling
export interface Location {
  name: string;
  latitude: number;
  longitude: number;
  sunHours: number;
  state?: string;
  country?: string;
}

// California solar data constants
export const CALIFORNIA_REGIONS: Location[] = [
  { name: "San Francisco", latitude: 37.7749, longitude: -122.4194, sunHours: 5.5 },
  { name: "Los Angeles", latitude: 34.0522, longitude: -118.2437, sunHours: 5.8 },
  { name: "San Diego", latitude: 32.7157, longitude: -117.1611, sunHours: 5.7 },
  { name: "Sacramento", latitude: 38.5816, longitude: -121.4944, sunHours: 5.4 },
  { name: "Fresno", latitude: 36.7378, longitude: -119.7871, sunHours: 5.9 },
  { name: "Palm Springs", latitude: 33.8303, longitude: -116.5453, sunHours: 6.2 }
];

// USA regions
export const USA_REGIONS: Location[] = [
  // California
  { name: "San Francisco", state: "CA", latitude: 37.7749, longitude: -122.4194, sunHours: 5.5 },
  { name: "Los Angeles", state: "CA", latitude: 34.0522, longitude: -118.2437, sunHours: 5.8 },
  { name: "San Diego", state: "CA", latitude: 32.7157, longitude: -117.1611, sunHours: 5.7 },
  
  // Texas
  { name: "Houston", state: "TX", latitude: 29.7604, longitude: -95.3698, sunHours: 5.3 },
  { name: "Austin", state: "TX", latitude: 30.2672, longitude: -97.7431, sunHours: 5.6 },
  { name: "Dallas", state: "TX", latitude: 32.7767, longitude: -96.7970, sunHours: 5.4 },
  
  // Florida
  { name: "Miami", state: "FL", latitude: 25.7617, longitude: -80.1918, sunHours: 5.8 },
  { name: "Orlando", state: "FL", latitude: 28.5383, longitude: -81.3792, sunHours: 5.9 },
  { name: "Tampa", state: "FL", latitude: 27.9506, longitude: -82.4572, sunHours: 5.7 },
  
  // Arizona
  { name: "Phoenix", state: "AZ", latitude: 33.4484, longitude: -112.0740, sunHours: 6.5 },
  { name: "Tucson", state: "AZ", latitude: 32.2226, longitude: -110.9747, sunHours: 6.3 },
  
  // Nevada
  { name: "Las Vegas", state: "NV", latitude: 36.1699, longitude: -115.1398, sunHours: 6.2 },
  
  // New York
  { name: "New York City", state: "NY", latitude: 40.7128, longitude: -74.0060, sunHours: 4.7 },
  { name: "Buffalo", state: "NY", latitude: 42.8864, longitude: -78.8784, sunHours: 4.2 },
  
  // Illinois
  { name: "Chicago", state: "IL", latitude: 41.8781, longitude: -87.6298, sunHours: 4.3 },
  
  // Colorado
  { name: "Denver", state: "CO", latitude: 39.7392, longitude: -104.9903, sunHours: 5.8 },
];

// European regions
export const EUROPEAN_REGIONS: Location[] = [
  // Germany
  { name: "Berlin", country: "Germany", latitude: 52.5200, longitude: 13.4050, sunHours: 3.7 },
  { name: "Munich", country: "Germany", latitude: 48.1351, longitude: 11.5820, sunHours: 4.2 },
  { name: "Hamburg", country: "Germany", latitude: 53.5511, longitude: 9.9937, sunHours: 3.5 },
  
  // Spain
  { name: "Madrid", country: "Spain", latitude: 40.4168, longitude: -3.7038, sunHours: 5.1 },
  { name: "Barcelona", country: "Spain", latitude: 41.3851, longitude: 2.1734, sunHours: 5.3 },
  { name: "Seville", country: "Spain", latitude: 37.3886, longitude: -5.9823, sunHours: 5.8 },
  
  // Italy
  { name: "Rome", country: "Italy", latitude: 41.9028, longitude: 12.4964, sunHours: 4.8 },
  { name: "Milan", country: "Italy", latitude: 45.4642, longitude: 9.1900, sunHours: 4.5 },
  { name: "Naples", country: "Italy", latitude: 40.8518, longitude: 14.2681, sunHours: 5.2 },
  
  // France
  { name: "Paris", country: "France", latitude: 48.8566, longitude: 2.3522, sunHours: 3.9 },
  { name: "Lyon", country: "France", latitude: 45.7640, longitude: 4.8357, sunHours: 4.3 },
  { name: "Marseille", country: "France", latitude: 43.2965, longitude: 5.3698, sunHours: 5.0 },
  
  // UK
  { name: "London", country: "UK", latitude: 51.5074, longitude: -0.1278, sunHours: 3.4 },
  { name: "Manchester", country: "UK", latitude: 53.4808, longitude: -2.2426, sunHours: 3.2 },
  
  // Netherlands
  { name: "Amsterdam", country: "Netherlands", latitude: 52.3676, longitude: 4.9041, sunHours: 3.6 },
  
  // Poland
  { name: "Warsaw", country: "Poland", latitude: 52.2297, longitude: 21.0122, sunHours: 4.0 },
  
  // Portugal
  { name: "Lisbon", country: "Portugal", latitude: 38.7223, longitude: -9.1393, sunHours: 5.4 },
];

// Worldwide regions
export const WORLDWIDE_REGIONS: Location[] = [
  ...USA_REGIONS.map(region => ({ ...region, country: "USA" })),
  ...EUROPEAN_REGIONS,
  
  // Asia
  { name: "Tokyo", country: "Japan", latitude: 35.6762, longitude: 139.6503, sunHours: 4.2 },
  { name: "Bangkok", country: "Thailand", latitude: 13.7563, longitude: 100.5018, sunHours: 5.9 },
  { name: "Dubai", country: "UAE", latitude: 25.2048, longitude: 55.2708, sunHours: 6.8 },
  { name: "Mumbai", country: "India", latitude: 19.0760, longitude: 72.8777, sunHours: 5.6 },
  
  // Australia/Oceania
  { name: "Sydney", country: "Australia", latitude: -33.8688, longitude: 151.2093, sunHours: 5.3 },
  { name: "Auckland", country: "New Zealand", latitude: -36.8509, longitude: 174.7645, sunHours: 4.6 },
  
  // Africa
  { name: "Cape Town", country: "South Africa", latitude: -33.9249, longitude: 18.4241, sunHours: 6.0 },
  { name: "Cairo", country: "Egypt", latitude: 30.0444, longitude: 31.2357, sunHours: 6.5 },
  
  // South America
  { name: "Rio de Janeiro", country: "Brazil", latitude: -22.9068, longitude: -43.1729, sunHours: 5.7 },
  { name: "Buenos Aires", country: "Argentina", latitude: -34.6037, longitude: -58.3816, sunHours: 5.2 }
];

// Solar panel efficiency data
export const PANEL_EFFICIENCIES = {
  standard: 0.18, // 18% efficiency
  premium: 0.21, // 21% efficiency
  highEnd: 0.23 // 23% efficiency
};

// Financial constants
export const FINANCIAL_CONSTANTS = {
  installationCostPerWatt: 2.5, // $2.50 per watt
  panelCostPerWatt: 0.50, // $0.50 per watt
  inverterCostPerWatt: 0.30, // $0.30 per watt
  mountingCostPerWatt: 0.20, // $0.20 per watt
  batteryCostPerWh: 0.50, // $0.50 per watt-hour
  averageElectricityRate: 0.27, // $0.27 per kWh in California
  federalTaxCredit: 0.30, // 30% federal tax credit
  californiaTaxCredit: 0.10 // 10% California state incentive
};

// System defaults
export const SYSTEM_DEFAULTS = {
  inverterEfficiency: 0.96, // 96% efficiency
  systemLosses: 0.14, // 14% system losses
  panelWattage: 400, // 400W panels
  defaultDailyUsage: 20, // 20 kWh per day
  defaultPanelEfficiency: PANEL_EFFICIENCIES.standard
};

// Job posting constants
export const JOB_CATEGORIES = [
  'Residential Solar Installation',
  'Commercial Solar Installation',
  'Solar Panel Maintenance',
  'Solar System Repair',
  'Battery Storage Installation',
  'Solar Consultation',
  'Permit & Design Services'
];

export const JOB_URGENCY_LEVELS = [
  { value: 'low', label: 'Within 30 days', color: 'bg-green-100 text-green-800' },
  { value: 'medium', label: 'Within 2 weeks', color: 'bg-yellow-100 text-yellow-800' },
  { value: 'high', label: 'Within 1 week', color: 'bg-orange-100 text-orange-800' },
  { value: 'urgent', label: 'ASAP', color: 'bg-red-100 text-red-800' }
];
